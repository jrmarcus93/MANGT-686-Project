﻿using Microsoft.VisualBasic;
using System;
using System.Collections;
using System.Collections.Generic;
using System.Data;
using System.Diagnostics;
namespace DormAssetTrackingSystem
{
    [Microsoft.VisualBasic.CompilerServices.DesignerGenerated()]
    partial class PurchaseRequisition : System.Windows.Forms.Form
    {

        //Form overrides dispose to clean up the component list.
        [System.Diagnostics.DebuggerNonUserCode()]
        protected override void Dispose(bool disposing)
        {
            try
            {
                if (disposing && components != null)
                {
                    components.Dispose();
                }
            }
            finally
            {
                base.Dispose(disposing);
            }
        }

        //Required by the Windows Form Designer

        private System.ComponentModel.IContainer components;
        //NOTE: The following procedure is required by the Windows Form Designer
        //It can be modified using the Windows Form Designer.  
        //Do not modify it using the code editor.
        [System.Diagnostics.DebuggerStepThrough()]
        private void InitializeComponent()
        {
            this.llManageUsers = new System.Windows.Forms.LinkLabel();
            this.llPurchaseRequisition = new System.Windows.Forms.LinkLabel();
            this.llRunViewReports = new System.Windows.Forms.LinkLabel();
            this.llLogOut = new System.Windows.Forms.LinkLabel();
            this.llUpdateRoomInventory = new System.Windows.Forms.LinkLabel();
            this.llHome = new System.Windows.Forms.LinkLabel();
            this.Splitter1 = new System.Windows.Forms.Splitter();
            this.lbPastPurchase = new System.Windows.Forms.ListBox();
            this.Label1 = new System.Windows.Forms.Label();
            this.Label2 = new System.Windows.Forms.Label();
            this.tbBeginningDate = new System.Windows.Forms.MaskedTextBox();
            this.Label3 = new System.Windows.Forms.Label();
            this.tbEndingDate = new System.Windows.Forms.MaskedTextBox();
            this.llExit = new System.Windows.Forms.LinkLabel();
            this.tbEndingDate1 = new System.Windows.Forms.MaskedTextBox();
            this.Label4 = new System.Windows.Forms.Label();
            this.tbBeginningDate1 = new System.Windows.Forms.MaskedTextBox();
            this.Label5 = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // llManageUsers
            // 
            this.llManageUsers.AutoSize = true;
            this.llManageUsers.BackColor = System.Drawing.Color.Indigo;
            this.llManageUsers.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F);
            this.llManageUsers.LinkColor = System.Drawing.Color.White;
            this.llManageUsers.Location = new System.Drawing.Point(10, 277);
            this.llManageUsers.Margin = new System.Windows.Forms.Padding(6, 0, 6, 0);
            this.llManageUsers.Name = "llManageUsers";
            this.llManageUsers.Size = new System.Drawing.Size(190, 31);
            this.llManageUsers.TabIndex = 20;
            this.llManageUsers.TabStop = true;
            this.llManageUsers.Text = "Manage Users";
            // 
            // llPurchaseRequisition
            // 
            this.llPurchaseRequisition.AutoSize = true;
            this.llPurchaseRequisition.BackColor = System.Drawing.Color.Indigo;
            this.llPurchaseRequisition.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F);
            this.llPurchaseRequisition.LinkColor = System.Drawing.Color.White;
            this.llPurchaseRequisition.Location = new System.Drawing.Point(12, 221);
            this.llPurchaseRequisition.Margin = new System.Windows.Forms.Padding(6, 0, 6, 0);
            this.llPurchaseRequisition.Name = "llPurchaseRequisition";
            this.llPurchaseRequisition.Size = new System.Drawing.Size(271, 31);
            this.llPurchaseRequisition.TabIndex = 19;
            this.llPurchaseRequisition.TabStop = true;
            this.llPurchaseRequisition.Text = "Purchase Requisition";
            // 
            // llRunViewReports
            // 
            this.llRunViewReports.AutoSize = true;
            this.llRunViewReports.BackColor = System.Drawing.Color.Indigo;
            this.llRunViewReports.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F);
            this.llRunViewReports.LinkColor = System.Drawing.Color.White;
            this.llRunViewReports.Location = new System.Drawing.Point(10, 163);
            this.llRunViewReports.Margin = new System.Windows.Forms.Padding(6, 0, 6, 0);
            this.llRunViewReports.Name = "llRunViewReports";
            this.llRunViewReports.Size = new System.Drawing.Size(234, 31);
            this.llRunViewReports.TabIndex = 18;
            this.llRunViewReports.TabStop = true;
            this.llRunViewReports.Text = "Run/View Reports";
            // 
            // llLogOut
            // 
            this.llLogOut.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.llLogOut.AutoSize = true;
            this.llLogOut.BackColor = System.Drawing.Color.Indigo;
            this.llLogOut.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F);
            this.llLogOut.LinkColor = System.Drawing.Color.White;
            this.llLogOut.Location = new System.Drawing.Point(10, 733);
            this.llLogOut.Margin = new System.Windows.Forms.Padding(6, 0, 6, 0);
            this.llLogOut.Name = "llLogOut";
            this.llLogOut.Size = new System.Drawing.Size(110, 31);
            this.llLogOut.TabIndex = 17;
            this.llLogOut.TabStop = true;
            this.llLogOut.Text = "Log Out";
            // 
            // llUpdateRoomInventory
            // 
            this.llUpdateRoomInventory.AutoSize = true;
            this.llUpdateRoomInventory.BackColor = System.Drawing.Color.Indigo;
            this.llUpdateRoomInventory.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F);
            this.llUpdateRoomInventory.LinkColor = System.Drawing.Color.White;
            this.llUpdateRoomInventory.Location = new System.Drawing.Point(12, 75);
            this.llUpdateRoomInventory.Margin = new System.Windows.Forms.Padding(6, 0, 6, 0);
            this.llUpdateRoomInventory.Name = "llUpdateRoomInventory";
            this.llUpdateRoomInventory.Size = new System.Drawing.Size(188, 62);
            this.llUpdateRoomInventory.TabIndex = 16;
            this.llUpdateRoomInventory.TabStop = true;
            this.llUpdateRoomInventory.Text = "Update Room \r\nInventory";
            // 
            // llHome
            // 
            this.llHome.AutoSize = true;
            this.llHome.BackColor = System.Drawing.Color.Indigo;
            this.llHome.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F);
            this.llHome.LinkColor = System.Drawing.Color.White;
            this.llHome.Location = new System.Drawing.Point(10, 17);
            this.llHome.Margin = new System.Windows.Forms.Padding(6, 0, 6, 0);
            this.llHome.Name = "llHome";
            this.llHome.Size = new System.Drawing.Size(86, 31);
            this.llHome.TabIndex = 15;
            this.llHome.TabStop = true;
            this.llHome.Text = "Home";
            // 
            // Splitter1
            // 
            this.Splitter1.BackColor = System.Drawing.Color.Indigo;
            this.Splitter1.Location = new System.Drawing.Point(0, 0);
            this.Splitter1.Margin = new System.Windows.Forms.Padding(6);
            this.Splitter1.Name = "Splitter1";
            this.Splitter1.Size = new System.Drawing.Size(316, 815);
            this.Splitter1.TabIndex = 14;
            this.Splitter1.TabStop = false;
            // 
            // lbPastPurchase
            // 
            this.lbPastPurchase.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.lbPastPurchase.FormattingEnabled = true;
            this.lbPastPurchase.ItemHeight = 25;
            this.lbPastPurchase.Location = new System.Drawing.Point(327, 565);
            this.lbPastPurchase.Margin = new System.Windows.Forms.Padding(6);
            this.lbPastPurchase.Name = "lbPastPurchase";
            this.lbPastPurchase.Size = new System.Drawing.Size(795, 229);
            this.lbPastPurchase.TabIndex = 21;
            // 
            // Label1
            // 
            this.Label1.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.Label1.AutoSize = true;
            this.Label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Underline))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Label1.Location = new System.Drawing.Point(322, 471);
            this.Label1.Margin = new System.Windows.Forms.Padding(6, 0, 6, 0);
            this.Label1.Name = "Label1";
            this.Label1.Size = new System.Drawing.Size(360, 30);
            this.Label1.TabIndex = 22;
            this.Label1.Text = "Past Purchase Requisitions:";
            // 
            // Label2
            // 
            this.Label2.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.Label2.AutoSize = true;
            this.Label2.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F);
            this.Label2.Location = new System.Drawing.Point(328, 519);
            this.Label2.Margin = new System.Windows.Forms.Padding(6, 0, 6, 0);
            this.Label2.Name = "Label2";
            this.Label2.Size = new System.Drawing.Size(120, 29);
            this.Label2.TabIndex = 23;
            this.Label2.Text = "View from";
            // 
            // tbBeginningDate
            // 
            this.tbBeginningDate.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.tbBeginningDate.Location = new System.Drawing.Point(454, 515);
            this.tbBeginningDate.Margin = new System.Windows.Forms.Padding(6);
            this.tbBeginningDate.Mask = "00/00/0000";
            this.tbBeginningDate.Name = "tbBeginningDate";
            this.tbBeginningDate.Size = new System.Drawing.Size(136, 31);
            this.tbBeginningDate.TabIndex = 24;
            this.tbBeginningDate.ValidatingType = typeof(System.DateTime);
            // 
            // Label3
            // 
            this.Label3.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.Label3.AutoSize = true;
            this.Label3.Location = new System.Drawing.Point(604, 521);
            this.Label3.Margin = new System.Windows.Forms.Padding(6, 0, 6, 0);
            this.Label3.Name = "Label3";
            this.Label3.Size = new System.Drawing.Size(30, 25);
            this.Label3.TabIndex = 25;
            this.Label3.Text = "to";
            // 
            // tbEndingDate
            // 
            this.tbEndingDate.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.tbEndingDate.Location = new System.Drawing.Point(648, 515);
            this.tbEndingDate.Margin = new System.Windows.Forms.Padding(6);
            this.tbEndingDate.Mask = "00/00/0000";
            this.tbEndingDate.Name = "tbEndingDate";
            this.tbEndingDate.Size = new System.Drawing.Size(136, 31);
            this.tbEndingDate.TabIndex = 26;
            this.tbEndingDate.ValidatingType = typeof(System.DateTime);
            // 
            // llExit
            // 
            this.llExit.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.llExit.AutoSize = true;
            this.llExit.BackColor = System.Drawing.Color.Indigo;
            this.llExit.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F);
            this.llExit.LinkColor = System.Drawing.Color.White;
            this.llExit.Location = new System.Drawing.Point(10, 765);
            this.llExit.Margin = new System.Windows.Forms.Padding(6, 0, 6, 0);
            this.llExit.Name = "llExit";
            this.llExit.Size = new System.Drawing.Size(59, 31);
            this.llExit.TabIndex = 27;
            this.llExit.TabStop = true;
            this.llExit.Text = "Exit";
            // 
            // tbEndingDate1
            // 
            this.tbEndingDate1.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.tbEndingDate1.Location = new System.Drawing.Point(648, 17);
            this.tbEndingDate1.Margin = new System.Windows.Forms.Padding(6);
            this.tbEndingDate1.Mask = "00/00/0000";
            this.tbEndingDate1.Name = "tbEndingDate1";
            this.tbEndingDate1.Size = new System.Drawing.Size(136, 31);
            this.tbEndingDate1.TabIndex = 31;
            this.tbEndingDate1.ValidatingType = typeof(System.DateTime);
            // 
            // Label4
            // 
            this.Label4.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.Label4.AutoSize = true;
            this.Label4.Location = new System.Drawing.Point(604, 23);
            this.Label4.Margin = new System.Windows.Forms.Padding(6, 0, 6, 0);
            this.Label4.Name = "Label4";
            this.Label4.Size = new System.Drawing.Size(30, 25);
            this.Label4.TabIndex = 30;
            this.Label4.Text = "to";
            // 
            // tbBeginningDate1
            // 
            this.tbBeginningDate1.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.tbBeginningDate1.Location = new System.Drawing.Point(454, 17);
            this.tbBeginningDate1.Margin = new System.Windows.Forms.Padding(6);
            this.tbBeginningDate1.Mask = "00/00/0000";
            this.tbBeginningDate1.Name = "tbBeginningDate1";
            this.tbBeginningDate1.Size = new System.Drawing.Size(136, 31);
            this.tbBeginningDate1.TabIndex = 29;
            this.tbBeginningDate1.ValidatingType = typeof(System.DateTime);
            // 
            // Label5
            // 
            this.Label5.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.Label5.AutoSize = true;
            this.Label5.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F);
            this.Label5.Location = new System.Drawing.Point(328, 21);
            this.Label5.Margin = new System.Windows.Forms.Padding(6, 0, 6, 0);
            this.Label5.Name = "Label5";
            this.Label5.Size = new System.Drawing.Size(120, 29);
            this.Label5.TabIndex = 28;
            this.Label5.Text = "View from";
            // 
            // PurchaseRequisition
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(12F, 25F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1146, 815);
            this.Controls.Add(this.tbEndingDate1);
            this.Controls.Add(this.Label4);
            this.Controls.Add(this.tbBeginningDate1);
            this.Controls.Add(this.Label5);
            this.Controls.Add(this.llExit);
            this.Controls.Add(this.tbEndingDate);
            this.Controls.Add(this.Label3);
            this.Controls.Add(this.tbBeginningDate);
            this.Controls.Add(this.Label2);
            this.Controls.Add(this.Label1);
            this.Controls.Add(this.lbPastPurchase);
            this.Controls.Add(this.llManageUsers);
            this.Controls.Add(this.llPurchaseRequisition);
            this.Controls.Add(this.llRunViewReports);
            this.Controls.Add(this.llLogOut);
            this.Controls.Add(this.llUpdateRoomInventory);
            this.Controls.Add(this.llHome);
            this.Controls.Add(this.Splitter1);
            this.Margin = new System.Windows.Forms.Padding(6);
            this.Name = "PurchaseRequisition";
            this.Text = "Purchase_Requisition";
            this.ResumeLayout(false);
            this.PerformLayout();

        }
        internal System.Windows.Forms.LinkLabel llManageUsers;
        internal System.Windows.Forms.LinkLabel llPurchaseRequisition;
        internal System.Windows.Forms.LinkLabel llRunViewReports;
        internal System.Windows.Forms.LinkLabel llLogOut;
        internal System.Windows.Forms.LinkLabel llUpdateRoomInventory;
        internal System.Windows.Forms.LinkLabel llHome;
        internal System.Windows.Forms.Splitter Splitter1;
        internal System.Windows.Forms.ListBox lbPastPurchase;
        internal System.Windows.Forms.Label Label1;
        internal System.Windows.Forms.Label Label2;
        internal System.Windows.Forms.MaskedTextBox tbBeginningDate;
        internal System.Windows.Forms.Label Label3;
        internal System.Windows.Forms.MaskedTextBox tbEndingDate;
        internal System.Windows.Forms.LinkLabel llExit;
        internal System.Windows.Forms.MaskedTextBox tbEndingDate1;
        internal System.Windows.Forms.Label Label4;
        internal System.Windows.Forms.MaskedTextBox tbBeginningDate1;
        internal System.Windows.Forms.Label Label5;
    }
}