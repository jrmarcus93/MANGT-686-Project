﻿
using Microsoft.VisualBasic;
using System;
using System.Collections;
using System.Collections.Generic;
using System.Data;
using System.Diagnostics;
namespace DormAssetTrackingSystem
{
    [Microsoft.VisualBasic.CompilerServices.DesignerGenerated()]
    partial class UpdateRoomInventory__4_Person : System.Windows.Forms.Form
    {

        //Form overrides dispose to clean up the component list.
        [System.Diagnostics.DebuggerNonUserCode()]
        protected override void Dispose(bool disposing)
        {
            try
            {
                if (disposing && components != null)
                {
                    components.Dispose();
                }
            }
            finally
            {
                base.Dispose(disposing);
            }
        }

        //Required by the Windows Form Designer

        private System.ComponentModel.IContainer components;
        //NOTE: The following procedure is required by the Windows Form Designer
        //It can be modified using the Windows Form Designer.  
        //Do not modify it using the code editor.
        [System.Diagnostics.DebuggerStepThrough()]
        private void InitializeComponent()
        {
            this.llManageUsers = new System.Windows.Forms.LinkLabel();
            this.llPurchaseRequisitions = new System.Windows.Forms.LinkLabel();
            this.llRunViewReports = new System.Windows.Forms.LinkLabel();
            this.llLogOut = new System.Windows.Forms.LinkLabel();
            this.llUpdateRoomInventory = new System.Windows.Forms.LinkLabel();
            this.llHome = new System.Windows.Forms.LinkLabel();
            this.Splitter1 = new System.Windows.Forms.Splitter();
            this.llExit = new System.Windows.Forms.LinkLabel();
            this.Label1 = new System.Windows.Forms.Label();
            this.Label2 = new System.Windows.Forms.Label();
            this.tbMattressIDNumber = new System.Windows.Forms.TextBox();
            this.cbMattressPresent = new System.Windows.Forms.CheckBox();
            this.Label3 = new System.Windows.Forms.Label();
            this.Label4 = new System.Windows.Forms.Label();
            this.cbMattressReplace = new System.Windows.Forms.CheckBox();
            this.tbMattressComments = new System.Windows.Forms.TextBox();
            this.Label5 = new System.Windows.Forms.Label();
            this.Label6 = new System.Windows.Forms.Label();
            this.Label7 = new System.Windows.Forms.Label();
            this.tbBedFrameComments = new System.Windows.Forms.TextBox();
            this.Label8 = new System.Windows.Forms.Label();
            this.cbBedFrameReplace = new System.Windows.Forms.CheckBox();
            this.Label9 = new System.Windows.Forms.Label();
            this.cbBedFramePresent = new System.Windows.Forms.CheckBox();
            this.tbBedFrameIDNumber = new System.Windows.Forms.TextBox();
            this.Label10 = new System.Windows.Forms.Label();
            this.Label11 = new System.Windows.Forms.Label();
            this.Label12 = new System.Windows.Forms.Label();
            this.tbDeskComments = new System.Windows.Forms.TextBox();
            this.Label13 = new System.Windows.Forms.Label();
            this.cbDeskReplace = new System.Windows.Forms.CheckBox();
            this.Label14 = new System.Windows.Forms.Label();
            this.cbDeskPresent = new System.Windows.Forms.CheckBox();
            this.tbDeskIDNumber = new System.Windows.Forms.TextBox();
            this.Label15 = new System.Windows.Forms.Label();
            this.Label16 = new System.Windows.Forms.Label();
            this.Label17 = new System.Windows.Forms.Label();
            this.tbDressersComments = new System.Windows.Forms.TextBox();
            this.Label18 = new System.Windows.Forms.Label();
            this.cbDressersReplace = new System.Windows.Forms.CheckBox();
            this.Label19 = new System.Windows.Forms.Label();
            this.cbDressersPresent = new System.Windows.Forms.CheckBox();
            this.tbDressersIdNumber = new System.Windows.Forms.TextBox();
            this.Label20 = new System.Windows.Forms.Label();
            this.Label21 = new System.Windows.Forms.Label();
            this.dlChairsQuantity = new System.Windows.Forms.ComboBox();
            this.Label22 = new System.Windows.Forms.Label();
            this.dlTrashCanQuantity = new System.Windows.Forms.ComboBox();
            this.Label23 = new System.Windows.Forms.Label();
            this.Label24 = new System.Windows.Forms.Label();
            this.tbRoomComments = new System.Windows.Forms.TextBox();
            this.bnSubmit = new System.Windows.Forms.Button();
            this.tbMattressComments2 = new System.Windows.Forms.TextBox();
            this.cbMattressReplace2 = new System.Windows.Forms.CheckBox();
            this.cbMattressPresent2 = new System.Windows.Forms.CheckBox();
            this.tbMattressIDNumber2 = new System.Windows.Forms.TextBox();
            this.tbBedFrameComments2 = new System.Windows.Forms.TextBox();
            this.cbBedFrameReplace2 = new System.Windows.Forms.CheckBox();
            this.cbBedFramePresent2 = new System.Windows.Forms.CheckBox();
            this.tbBedFrameIDNumber2 = new System.Windows.Forms.TextBox();
            this.tbDesksComments2 = new System.Windows.Forms.TextBox();
            this.cbDesksReplace2 = new System.Windows.Forms.CheckBox();
            this.cbDesksPresent2 = new System.Windows.Forms.CheckBox();
            this.tbDesksIDNumber2 = new System.Windows.Forms.TextBox();
            this.tbDressersComments2 = new System.Windows.Forms.TextBox();
            this.cbDressersReplace2 = new System.Windows.Forms.CheckBox();
            this.cbDressersPresent2 = new System.Windows.Forms.CheckBox();
            this.tbDressersIDNumber2 = new System.Windows.Forms.TextBox();
            this.tbMattressComments3 = new System.Windows.Forms.TextBox();
            this.cbMattressReplace3 = new System.Windows.Forms.CheckBox();
            this.cbMattressPresent3 = new System.Windows.Forms.CheckBox();
            this.tbMattressIDNumber3 = new System.Windows.Forms.TextBox();
            this.tbBedFrameComments3 = new System.Windows.Forms.TextBox();
            this.cbBedFrameReplace3 = new System.Windows.Forms.CheckBox();
            this.cbBedFramePresent3 = new System.Windows.Forms.CheckBox();
            this.tbBedFrameIDNumber3 = new System.Windows.Forms.TextBox();
            this.tbDesksComments3 = new System.Windows.Forms.TextBox();
            this.cbDesksReplace3 = new System.Windows.Forms.CheckBox();
            this.cbDesksPresent3 = new System.Windows.Forms.CheckBox();
            this.tbDesksIDNumber3 = new System.Windows.Forms.TextBox();
            this.tbDressersComments3 = new System.Windows.Forms.TextBox();
            this.cbDressersReplace3 = new System.Windows.Forms.CheckBox();
            this.cbDressersPresent3 = new System.Windows.Forms.CheckBox();
            this.tbDressersIDNumber3 = new System.Windows.Forms.TextBox();
            this.tbMattressComments4 = new System.Windows.Forms.TextBox();
            this.cbMattressReplace4 = new System.Windows.Forms.CheckBox();
            this.cbMattressPresent4 = new System.Windows.Forms.CheckBox();
            this.tbMattressIDNumber4 = new System.Windows.Forms.TextBox();
            this.tbBedFrameComments4 = new System.Windows.Forms.TextBox();
            this.cbBedFrameReplace4 = new System.Windows.Forms.CheckBox();
            this.cbBedFramePresent4 = new System.Windows.Forms.CheckBox();
            this.tbBedFrameIDNumber4 = new System.Windows.Forms.TextBox();
            this.tbDesksComments4 = new System.Windows.Forms.TextBox();
            this.cbDesksReplace4 = new System.Windows.Forms.CheckBox();
            this.cbDesksPresent4 = new System.Windows.Forms.CheckBox();
            this.tbDesksIDNumber4 = new System.Windows.Forms.TextBox();
            this.tbDressersComments4 = new System.Windows.Forms.TextBox();
            this.cbDressersReplace4 = new System.Windows.Forms.CheckBox();
            this.cbDressersPresent4 = new System.Windows.Forms.CheckBox();
            this.tbDressersIDNumebr4 = new System.Windows.Forms.TextBox();
            this.SuspendLayout();
            // 
            // llManageUsers
            // 
            this.llManageUsers.AutoSize = true;
            this.llManageUsers.BackColor = System.Drawing.Color.Indigo;
            this.llManageUsers.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F);
            this.llManageUsers.LinkColor = System.Drawing.Color.White;
            this.llManageUsers.Location = new System.Drawing.Point(4, 144);
            this.llManageUsers.Name = "llManageUsers";
            this.llManageUsers.Size = new System.Drawing.Size(100, 17);
            this.llManageUsers.TabIndex = 27;
            this.llManageUsers.TabStop = true;
            this.llManageUsers.Text = "Manage Users";
            // 
            // llPurchaseRequisitions
            // 
            this.llPurchaseRequisitions.AutoSize = true;
            this.llPurchaseRequisitions.BackColor = System.Drawing.Color.Indigo;
            this.llPurchaseRequisitions.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F);
            this.llPurchaseRequisitions.LinkColor = System.Drawing.Color.White;
            this.llPurchaseRequisitions.Location = new System.Drawing.Point(5, 114);
            this.llPurchaseRequisitions.Name = "llPurchaseRequisitions";
            this.llPurchaseRequisitions.Size = new System.Drawing.Size(142, 17);
            this.llPurchaseRequisitions.TabIndex = 26;
            this.llPurchaseRequisitions.TabStop = true;
            this.llPurchaseRequisitions.Text = "Purchase Requisition";
            // 
            // llRunViewReports
            // 
            this.llRunViewReports.AutoSize = true;
            this.llRunViewReports.BackColor = System.Drawing.Color.Indigo;
            this.llRunViewReports.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F);
            this.llRunViewReports.LinkColor = System.Drawing.Color.White;
            this.llRunViewReports.Location = new System.Drawing.Point(4, 84);
            this.llRunViewReports.Name = "llRunViewReports";
            this.llRunViewReports.Size = new System.Drawing.Size(121, 17);
            this.llRunViewReports.TabIndex = 25;
            this.llRunViewReports.TabStop = true;
            this.llRunViewReports.Text = "Run/View Reports";
            // 
            // llLogOut
            // 
            this.llLogOut.Anchor = System.Windows.Forms.AnchorStyles.Left;
            this.llLogOut.AutoSize = true;
            this.llLogOut.BackColor = System.Drawing.Color.Indigo;
            this.llLogOut.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F);
            this.llLogOut.LinkColor = System.Drawing.Color.White;
            this.llLogOut.Location = new System.Drawing.Point(5, 640);
            this.llLogOut.Name = "llLogOut";
            this.llLogOut.Size = new System.Drawing.Size(59, 17);
            this.llLogOut.TabIndex = 24;
            this.llLogOut.TabStop = true;
            this.llLogOut.Text = "Log Out";
            // 
            // llUpdateRoomInventory
            // 
            this.llUpdateRoomInventory.AutoSize = true;
            this.llUpdateRoomInventory.BackColor = System.Drawing.Color.Indigo;
            this.llUpdateRoomInventory.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F);
            this.llUpdateRoomInventory.LinkColor = System.Drawing.Color.White;
            this.llUpdateRoomInventory.Location = new System.Drawing.Point(5, 38);
            this.llUpdateRoomInventory.Name = "llUpdateRoomInventory";
            this.llUpdateRoomInventory.Size = new System.Drawing.Size(99, 34);
            this.llUpdateRoomInventory.TabIndex = 23;
            this.llUpdateRoomInventory.TabStop = true;
            this.llUpdateRoomInventory.Text = "Update Room \r\nInventory";
            // 
            // llHome
            // 
            this.llHome.AutoSize = true;
            this.llHome.BackColor = System.Drawing.Color.Indigo;
            this.llHome.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F);
            this.llHome.LinkColor = System.Drawing.Color.White;
            this.llHome.Location = new System.Drawing.Point(5, 9);
            this.llHome.Name = "llHome";
            this.llHome.Size = new System.Drawing.Size(45, 17);
            this.llHome.TabIndex = 22;
            this.llHome.TabStop = true;
            this.llHome.Text = "Home";
            // 
            // Splitter1
            // 
            this.Splitter1.BackColor = System.Drawing.Color.Indigo;
            this.Splitter1.Location = new System.Drawing.Point(0, 0);
            this.Splitter1.Name = "Splitter1";
            this.Splitter1.Size = new System.Drawing.Size(156, 692);
            this.Splitter1.TabIndex = 21;
            this.Splitter1.TabStop = false;
            // 
            // llExit
            // 
            this.llExit.Anchor = System.Windows.Forms.AnchorStyles.Left;
            this.llExit.AutoSize = true;
            this.llExit.BackColor = System.Drawing.Color.Indigo;
            this.llExit.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F);
            this.llExit.LinkColor = System.Drawing.Color.White;
            this.llExit.Location = new System.Drawing.Point(5, 666);
            this.llExit.Name = "llExit";
            this.llExit.Size = new System.Drawing.Size(30, 17);
            this.llExit.TabIndex = 28;
            this.llExit.TabStop = true;
            this.llExit.Text = "Exit";
            // 
            // Label1
            // 
            this.Label1.Anchor = System.Windows.Forms.AnchorStyles.Top;
            this.Label1.AutoSize = true;
            this.Label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Underline))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Label1.Location = new System.Drawing.Point(340, 9);
            this.Label1.Name = "Label1";
            this.Label1.Size = new System.Drawing.Size(87, 24);
            this.Label1.TabIndex = 29;
            this.Label1.Text = "Mattress";
            // 
            // Label2
            // 
            this.Label2.Anchor = System.Windows.Forms.AnchorStyles.Top;
            this.Label2.AutoSize = true;
            this.Label2.Location = new System.Drawing.Point(214, 37);
            this.Label2.Name = "Label2";
            this.Label2.Size = new System.Drawing.Size(58, 13);
            this.Label2.TabIndex = 30;
            this.Label2.Text = "ID Number";
            // 
            // tbMattressIDNumber
            // 
            this.tbMattressIDNumber.Anchor = System.Windows.Forms.AnchorStyles.Top;
            this.tbMattressIDNumber.Location = new System.Drawing.Point(179, 51);
            this.tbMattressIDNumber.Name = "tbMattressIDNumber";
            this.tbMattressIDNumber.Size = new System.Drawing.Size(127, 20);
            this.tbMattressIDNumber.TabIndex = 31;
            // 
            // cbMattressPresent
            // 
            this.cbMattressPresent.Anchor = System.Windows.Forms.AnchorStyles.Top;
            this.cbMattressPresent.Location = new System.Drawing.Point(350, 54);
            this.cbMattressPresent.Name = "cbMattressPresent";
            this.cbMattressPresent.Size = new System.Drawing.Size(15, 14);
            this.cbMattressPresent.TabIndex = 32;
            this.cbMattressPresent.UseVisualStyleBackColor = true;
            // 
            // Label3
            // 
            this.Label3.Anchor = System.Windows.Forms.AnchorStyles.Top;
            this.Label3.AutoSize = true;
            this.Label3.Location = new System.Drawing.Point(337, 37);
            this.Label3.Name = "Label3";
            this.Label3.Size = new System.Drawing.Size(49, 13);
            this.Label3.TabIndex = 33;
            this.Label3.Text = "Present?";
            // 
            // Label4
            // 
            this.Label4.Anchor = System.Windows.Forms.AnchorStyles.Top;
            this.Label4.AutoSize = true;
            this.Label4.Location = new System.Drawing.Point(392, 37);
            this.Label4.Name = "Label4";
            this.Label4.Size = new System.Drawing.Size(53, 13);
            this.Label4.TabIndex = 35;
            this.Label4.Text = "Replace?";
            // 
            // cbMattressReplace
            // 
            this.cbMattressReplace.Anchor = System.Windows.Forms.AnchorStyles.Top;
            this.cbMattressReplace.Location = new System.Drawing.Point(407, 53);
            this.cbMattressReplace.Name = "cbMattressReplace";
            this.cbMattressReplace.Size = new System.Drawing.Size(16, 17);
            this.cbMattressReplace.TabIndex = 34;
            this.cbMattressReplace.UseVisualStyleBackColor = true;
            // 
            // tbMattressComments
            // 
            this.tbMattressComments.Anchor = System.Windows.Forms.AnchorStyles.Top;
            this.tbMattressComments.Location = new System.Drawing.Point(465, 49);
            this.tbMattressComments.Name = "tbMattressComments";
            this.tbMattressComments.Size = new System.Drawing.Size(177, 20);
            this.tbMattressComments.TabIndex = 36;
            // 
            // Label5
            // 
            this.Label5.Anchor = System.Windows.Forms.AnchorStyles.Top;
            this.Label5.AutoSize = true;
            this.Label5.Location = new System.Drawing.Point(521, 36);
            this.Label5.Name = "Label5";
            this.Label5.Size = new System.Drawing.Size(56, 13);
            this.Label5.TabIndex = 37;
            this.Label5.Text = "Comments";
            // 
            // Label6
            // 
            this.Label6.Anchor = System.Windows.Forms.AnchorStyles.Top;
            this.Label6.AutoSize = true;
            this.Label6.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Underline))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Label6.Location = new System.Drawing.Point(334, 146);
            this.Label6.Name = "Label6";
            this.Label6.Size = new System.Drawing.Size(113, 24);
            this.Label6.TabIndex = 38;
            this.Label6.Text = "Bed Frame";
            // 
            // Label7
            // 
            this.Label7.Anchor = System.Windows.Forms.AnchorStyles.Top;
            this.Label7.AutoSize = true;
            this.Label7.Location = new System.Drawing.Point(521, 174);
            this.Label7.Name = "Label7";
            this.Label7.Size = new System.Drawing.Size(56, 13);
            this.Label7.TabIndex = 46;
            this.Label7.Text = "Comments";
            // 
            // tbBedFrameComments
            // 
            this.tbBedFrameComments.Anchor = System.Windows.Forms.AnchorStyles.Top;
            this.tbBedFrameComments.Location = new System.Drawing.Point(465, 187);
            this.tbBedFrameComments.Name = "tbBedFrameComments";
            this.tbBedFrameComments.Size = new System.Drawing.Size(177, 20);
            this.tbBedFrameComments.TabIndex = 45;
            // 
            // Label8
            // 
            this.Label8.Anchor = System.Windows.Forms.AnchorStyles.Top;
            this.Label8.AutoSize = true;
            this.Label8.Location = new System.Drawing.Point(392, 175);
            this.Label8.Name = "Label8";
            this.Label8.Size = new System.Drawing.Size(53, 13);
            this.Label8.TabIndex = 44;
            this.Label8.Text = "Replace?";
            // 
            // cbBedFrameReplace
            // 
            this.cbBedFrameReplace.Anchor = System.Windows.Forms.AnchorStyles.Top;
            this.cbBedFrameReplace.Location = new System.Drawing.Point(407, 191);
            this.cbBedFrameReplace.Name = "cbBedFrameReplace";
            this.cbBedFrameReplace.Size = new System.Drawing.Size(16, 17);
            this.cbBedFrameReplace.TabIndex = 43;
            this.cbBedFrameReplace.UseVisualStyleBackColor = true;
            // 
            // Label9
            // 
            this.Label9.Anchor = System.Windows.Forms.AnchorStyles.Top;
            this.Label9.AutoSize = true;
            this.Label9.Location = new System.Drawing.Point(337, 175);
            this.Label9.Name = "Label9";
            this.Label9.Size = new System.Drawing.Size(49, 13);
            this.Label9.TabIndex = 42;
            this.Label9.Text = "Present?";
            // 
            // cbBedFramePresent
            // 
            this.cbBedFramePresent.Anchor = System.Windows.Forms.AnchorStyles.Top;
            this.cbBedFramePresent.Location = new System.Drawing.Point(350, 192);
            this.cbBedFramePresent.Name = "cbBedFramePresent";
            this.cbBedFramePresent.Size = new System.Drawing.Size(15, 14);
            this.cbBedFramePresent.TabIndex = 41;
            this.cbBedFramePresent.UseVisualStyleBackColor = true;
            // 
            // tbBedFrameIDNumber
            // 
            this.tbBedFrameIDNumber.Anchor = System.Windows.Forms.AnchorStyles.Top;
            this.tbBedFrameIDNumber.Location = new System.Drawing.Point(179, 189);
            this.tbBedFrameIDNumber.Name = "tbBedFrameIDNumber";
            this.tbBedFrameIDNumber.Size = new System.Drawing.Size(127, 20);
            this.tbBedFrameIDNumber.TabIndex = 40;
            // 
            // Label10
            // 
            this.Label10.Anchor = System.Windows.Forms.AnchorStyles.Top;
            this.Label10.AutoSize = true;
            this.Label10.Location = new System.Drawing.Point(214, 175);
            this.Label10.Name = "Label10";
            this.Label10.Size = new System.Drawing.Size(58, 13);
            this.Label10.TabIndex = 39;
            this.Label10.Text = "ID Number";
            // 
            // Label11
            // 
            this.Label11.Anchor = System.Windows.Forms.AnchorStyles.Top;
            this.Label11.AutoSize = true;
            this.Label11.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Label11.Location = new System.Drawing.Point(176, 579);
            this.Label11.Name = "Label11";
            this.Label11.Size = new System.Drawing.Size(68, 20);
            this.Label11.TabIndex = 47;
            this.Label11.Text = "Chair(s):";
            // 
            // Label12
            // 
            this.Label12.Anchor = System.Windows.Forms.AnchorStyles.Top;
            this.Label12.AutoSize = true;
            this.Label12.Location = new System.Drawing.Point(521, 304);
            this.Label12.Name = "Label12";
            this.Label12.Size = new System.Drawing.Size(56, 13);
            this.Label12.TabIndex = 56;
            this.Label12.Text = "Comments";
            // 
            // tbDeskComments
            // 
            this.tbDeskComments.Anchor = System.Windows.Forms.AnchorStyles.Top;
            this.tbDeskComments.Location = new System.Drawing.Point(465, 317);
            this.tbDeskComments.Name = "tbDeskComments";
            this.tbDeskComments.Size = new System.Drawing.Size(177, 20);
            this.tbDeskComments.TabIndex = 55;
            // 
            // Label13
            // 
            this.Label13.Anchor = System.Windows.Forms.AnchorStyles.Top;
            this.Label13.AutoSize = true;
            this.Label13.Location = new System.Drawing.Point(392, 305);
            this.Label13.Name = "Label13";
            this.Label13.Size = new System.Drawing.Size(53, 13);
            this.Label13.TabIndex = 54;
            this.Label13.Text = "Replace?";
            // 
            // cbDeskReplace
            // 
            this.cbDeskReplace.Anchor = System.Windows.Forms.AnchorStyles.Top;
            this.cbDeskReplace.Location = new System.Drawing.Point(407, 321);
            this.cbDeskReplace.Name = "cbDeskReplace";
            this.cbDeskReplace.Size = new System.Drawing.Size(16, 17);
            this.cbDeskReplace.TabIndex = 53;
            this.cbDeskReplace.UseVisualStyleBackColor = true;
            // 
            // Label14
            // 
            this.Label14.Anchor = System.Windows.Forms.AnchorStyles.Top;
            this.Label14.AutoSize = true;
            this.Label14.Location = new System.Drawing.Point(337, 305);
            this.Label14.Name = "Label14";
            this.Label14.Size = new System.Drawing.Size(49, 13);
            this.Label14.TabIndex = 52;
            this.Label14.Text = "Present?";
            // 
            // cbDeskPresent
            // 
            this.cbDeskPresent.Anchor = System.Windows.Forms.AnchorStyles.Top;
            this.cbDeskPresent.Location = new System.Drawing.Point(350, 322);
            this.cbDeskPresent.Name = "cbDeskPresent";
            this.cbDeskPresent.Size = new System.Drawing.Size(15, 14);
            this.cbDeskPresent.TabIndex = 51;
            this.cbDeskPresent.UseVisualStyleBackColor = true;
            // 
            // tbDeskIDNumber
            // 
            this.tbDeskIDNumber.Anchor = System.Windows.Forms.AnchorStyles.Top;
            this.tbDeskIDNumber.Location = new System.Drawing.Point(179, 319);
            this.tbDeskIDNumber.Name = "tbDeskIDNumber";
            this.tbDeskIDNumber.Size = new System.Drawing.Size(127, 20);
            this.tbDeskIDNumber.TabIndex = 50;
            // 
            // Label15
            // 
            this.Label15.Anchor = System.Windows.Forms.AnchorStyles.Top;
            this.Label15.AutoSize = true;
            this.Label15.Location = new System.Drawing.Point(214, 305);
            this.Label15.Name = "Label15";
            this.Label15.Size = new System.Drawing.Size(58, 13);
            this.Label15.TabIndex = 49;
            this.Label15.Text = "ID Number";
            // 
            // Label16
            // 
            this.Label16.Anchor = System.Windows.Forms.AnchorStyles.Top;
            this.Label16.AutoSize = true;
            this.Label16.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Underline))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Label16.Location = new System.Drawing.Point(354, 278);
            this.Label16.Name = "Label16";
            this.Label16.Size = new System.Drawing.Size(66, 24);
            this.Label16.TabIndex = 48;
            this.Label16.Text = "Desks";
            // 
            // Label17
            // 
            this.Label17.Anchor = System.Windows.Forms.AnchorStyles.Top;
            this.Label17.AutoSize = true;
            this.Label17.Location = new System.Drawing.Point(522, 443);
            this.Label17.Name = "Label17";
            this.Label17.Size = new System.Drawing.Size(56, 13);
            this.Label17.TabIndex = 65;
            this.Label17.Text = "Comments";
            // 
            // tbDressersComments
            // 
            this.tbDressersComments.Anchor = System.Windows.Forms.AnchorStyles.Top;
            this.tbDressersComments.Location = new System.Drawing.Point(466, 456);
            this.tbDressersComments.Name = "tbDressersComments";
            this.tbDressersComments.Size = new System.Drawing.Size(177, 20);
            this.tbDressersComments.TabIndex = 64;
            // 
            // Label18
            // 
            this.Label18.Anchor = System.Windows.Forms.AnchorStyles.Top;
            this.Label18.AutoSize = true;
            this.Label18.Location = new System.Drawing.Point(392, 444);
            this.Label18.Name = "Label18";
            this.Label18.Size = new System.Drawing.Size(53, 13);
            this.Label18.TabIndex = 63;
            this.Label18.Text = "Replace?";
            // 
            // cbDressersReplace
            // 
            this.cbDressersReplace.Anchor = System.Windows.Forms.AnchorStyles.Top;
            this.cbDressersReplace.Location = new System.Drawing.Point(408, 460);
            this.cbDressersReplace.Name = "cbDressersReplace";
            this.cbDressersReplace.Size = new System.Drawing.Size(16, 17);
            this.cbDressersReplace.TabIndex = 62;
            this.cbDressersReplace.UseVisualStyleBackColor = true;
            // 
            // Label19
            // 
            this.Label19.Anchor = System.Windows.Forms.AnchorStyles.Top;
            this.Label19.AutoSize = true;
            this.Label19.Location = new System.Drawing.Point(338, 444);
            this.Label19.Name = "Label19";
            this.Label19.Size = new System.Drawing.Size(49, 13);
            this.Label19.TabIndex = 61;
            this.Label19.Text = "Present?";
            // 
            // cbDressersPresent
            // 
            this.cbDressersPresent.Anchor = System.Windows.Forms.AnchorStyles.Top;
            this.cbDressersPresent.Location = new System.Drawing.Point(350, 461);
            this.cbDressersPresent.Name = "cbDressersPresent";
            this.cbDressersPresent.Size = new System.Drawing.Size(15, 14);
            this.cbDressersPresent.TabIndex = 60;
            this.cbDressersPresent.UseVisualStyleBackColor = true;
            // 
            // tbDressersIdNumber
            // 
            this.tbDressersIdNumber.Anchor = System.Windows.Forms.AnchorStyles.Top;
            this.tbDressersIdNumber.Location = new System.Drawing.Point(180, 458);
            this.tbDressersIdNumber.Name = "tbDressersIdNumber";
            this.tbDressersIdNumber.Size = new System.Drawing.Size(127, 20);
            this.tbDressersIdNumber.TabIndex = 59;
            // 
            // Label20
            // 
            this.Label20.Anchor = System.Windows.Forms.AnchorStyles.Top;
            this.Label20.AutoSize = true;
            this.Label20.Location = new System.Drawing.Point(214, 444);
            this.Label20.Name = "Label20";
            this.Label20.Size = new System.Drawing.Size(58, 13);
            this.Label20.TabIndex = 58;
            this.Label20.Text = "ID Number";
            // 
            // Label21
            // 
            this.Label21.Anchor = System.Windows.Forms.AnchorStyles.Top;
            this.Label21.AutoSize = true;
            this.Label21.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Underline))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Label21.Location = new System.Drawing.Point(343, 414);
            this.Label21.Name = "Label21";
            this.Label21.Size = new System.Drawing.Size(92, 24);
            this.Label21.TabIndex = 57;
            this.Label21.Text = "Dressers";
            // 
            // dlChairsQuantity
            // 
            this.dlChairsQuantity.Anchor = System.Windows.Forms.AnchorStyles.Top;
            this.dlChairsQuantity.FormattingEnabled = true;
            this.dlChairsQuantity.Items.AddRange(new object[] {
            "1",
            "2",
            "3",
            "4",
            "5",
            "6"});
            this.dlChairsQuantity.Location = new System.Drawing.Point(274, 581);
            this.dlChairsQuantity.Name = "dlChairsQuantity";
            this.dlChairsQuantity.Size = new System.Drawing.Size(46, 21);
            this.dlChairsQuantity.TabIndex = 66;
            // 
            // Label22
            // 
            this.Label22.Anchor = System.Windows.Forms.AnchorStyles.Top;
            this.Label22.AutoSize = true;
            this.Label22.Location = new System.Drawing.Point(264, 562);
            this.Label22.Name = "Label22";
            this.Label22.Size = new System.Drawing.Size(71, 13);
            this.Label22.TabIndex = 67;
            this.Label22.Text = "Qty. Present?";
            // 
            // dlTrashCanQuantity
            // 
            this.dlTrashCanQuantity.Anchor = System.Windows.Forms.AnchorStyles.Top;
            this.dlTrashCanQuantity.FormattingEnabled = true;
            this.dlTrashCanQuantity.Items.AddRange(new object[] {
            "1",
            "2",
            "3",
            "4",
            "5",
            "6"});
            this.dlTrashCanQuantity.Location = new System.Drawing.Point(274, 615);
            this.dlTrashCanQuantity.Name = "dlTrashCanQuantity";
            this.dlTrashCanQuantity.Size = new System.Drawing.Size(46, 21);
            this.dlTrashCanQuantity.TabIndex = 69;
            // 
            // Label23
            // 
            this.Label23.Anchor = System.Windows.Forms.AnchorStyles.Top;
            this.Label23.AutoSize = true;
            this.Label23.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Label23.Location = new System.Drawing.Point(176, 613);
            this.Label23.Name = "Label23";
            this.Label23.Size = new System.Drawing.Size(94, 20);
            this.Label23.TabIndex = 68;
            this.Label23.Text = "Trash Cans:";
            // 
            // Label24
            // 
            this.Label24.Anchor = System.Windows.Forms.AnchorStyles.Top;
            this.Label24.AutoSize = true;
            this.Label24.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Label24.Location = new System.Drawing.Point(346, 579);
            this.Label24.Name = "Label24";
            this.Label24.Size = new System.Drawing.Size(90, 40);
            this.Label24.TabIndex = 70;
            this.Label24.Text = "Room \r\nComments:";
            // 
            // tbRoomComments
            // 
            this.tbRoomComments.Anchor = System.Windows.Forms.AnchorStyles.Top;
            this.tbRoomComments.Location = new System.Drawing.Point(442, 579);
            this.tbRoomComments.Multiline = true;
            this.tbRoomComments.Name = "tbRoomComments";
            this.tbRoomComments.Size = new System.Drawing.Size(200, 73);
            this.tbRoomComments.TabIndex = 71;
            // 
            // bnSubmit
            // 
            this.bnSubmit.Anchor = System.Windows.Forms.AnchorStyles.Top;
            this.bnSubmit.BackColor = System.Drawing.SystemColors.Control;
            this.bnSubmit.Location = new System.Drawing.Point(330, 659);
            this.bnSubmit.Name = "bnSubmit";
            this.bnSubmit.Size = new System.Drawing.Size(75, 23);
            this.bnSubmit.TabIndex = 72;
            this.bnSubmit.Text = "Submit";
            this.bnSubmit.UseVisualStyleBackColor = false;
            // 
            // tbMattressComments2
            // 
            this.tbMattressComments2.Anchor = System.Windows.Forms.AnchorStyles.Top;
            this.tbMattressComments2.Location = new System.Drawing.Point(465, 71);
            this.tbMattressComments2.Name = "tbMattressComments2";
            this.tbMattressComments2.Size = new System.Drawing.Size(177, 20);
            this.tbMattressComments2.TabIndex = 76;
            // 
            // cbMattressReplace2
            // 
            this.cbMattressReplace2.Anchor = System.Windows.Forms.AnchorStyles.Top;
            this.cbMattressReplace2.Location = new System.Drawing.Point(407, 75);
            this.cbMattressReplace2.Name = "cbMattressReplace2";
            this.cbMattressReplace2.Size = new System.Drawing.Size(16, 17);
            this.cbMattressReplace2.TabIndex = 75;
            this.cbMattressReplace2.UseVisualStyleBackColor = true;
            // 
            // cbMattressPresent2
            // 
            this.cbMattressPresent2.Anchor = System.Windows.Forms.AnchorStyles.Top;
            this.cbMattressPresent2.Location = new System.Drawing.Point(350, 76);
            this.cbMattressPresent2.Name = "cbMattressPresent2";
            this.cbMattressPresent2.Size = new System.Drawing.Size(15, 14);
            this.cbMattressPresent2.TabIndex = 74;
            this.cbMattressPresent2.UseVisualStyleBackColor = true;
            // 
            // tbMattressIDNumber2
            // 
            this.tbMattressIDNumber2.Anchor = System.Windows.Forms.AnchorStyles.Top;
            this.tbMattressIDNumber2.Location = new System.Drawing.Point(179, 73);
            this.tbMattressIDNumber2.Name = "tbMattressIDNumber2";
            this.tbMattressIDNumber2.Size = new System.Drawing.Size(127, 20);
            this.tbMattressIDNumber2.TabIndex = 73;
            // 
            // tbBedFrameComments2
            // 
            this.tbBedFrameComments2.Anchor = System.Windows.Forms.AnchorStyles.Top;
            this.tbBedFrameComments2.Location = new System.Drawing.Point(465, 210);
            this.tbBedFrameComments2.Name = "tbBedFrameComments2";
            this.tbBedFrameComments2.Size = new System.Drawing.Size(177, 20);
            this.tbBedFrameComments2.TabIndex = 80;
            // 
            // cbBedFrameReplace2
            // 
            this.cbBedFrameReplace2.Anchor = System.Windows.Forms.AnchorStyles.Top;
            this.cbBedFrameReplace2.Location = new System.Drawing.Point(407, 214);
            this.cbBedFrameReplace2.Name = "cbBedFrameReplace2";
            this.cbBedFrameReplace2.Size = new System.Drawing.Size(16, 17);
            this.cbBedFrameReplace2.TabIndex = 79;
            this.cbBedFrameReplace2.UseVisualStyleBackColor = true;
            // 
            // cbBedFramePresent2
            // 
            this.cbBedFramePresent2.Anchor = System.Windows.Forms.AnchorStyles.Top;
            this.cbBedFramePresent2.Location = new System.Drawing.Point(350, 215);
            this.cbBedFramePresent2.Name = "cbBedFramePresent2";
            this.cbBedFramePresent2.Size = new System.Drawing.Size(15, 14);
            this.cbBedFramePresent2.TabIndex = 78;
            this.cbBedFramePresent2.UseVisualStyleBackColor = true;
            // 
            // tbBedFrameIDNumber2
            // 
            this.tbBedFrameIDNumber2.Anchor = System.Windows.Forms.AnchorStyles.Top;
            this.tbBedFrameIDNumber2.Location = new System.Drawing.Point(179, 212);
            this.tbBedFrameIDNumber2.Name = "tbBedFrameIDNumber2";
            this.tbBedFrameIDNumber2.Size = new System.Drawing.Size(127, 20);
            this.tbBedFrameIDNumber2.TabIndex = 77;
            // 
            // tbDesksComments2
            // 
            this.tbDesksComments2.Anchor = System.Windows.Forms.AnchorStyles.Top;
            this.tbDesksComments2.Location = new System.Drawing.Point(466, 340);
            this.tbDesksComments2.Name = "tbDesksComments2";
            this.tbDesksComments2.Size = new System.Drawing.Size(177, 20);
            this.tbDesksComments2.TabIndex = 84;
            // 
            // cbDesksReplace2
            // 
            this.cbDesksReplace2.Anchor = System.Windows.Forms.AnchorStyles.Top;
            this.cbDesksReplace2.Location = new System.Drawing.Point(408, 344);
            this.cbDesksReplace2.Name = "cbDesksReplace2";
            this.cbDesksReplace2.Size = new System.Drawing.Size(16, 17);
            this.cbDesksReplace2.TabIndex = 83;
            this.cbDesksReplace2.UseVisualStyleBackColor = true;
            // 
            // cbDesksPresent2
            // 
            this.cbDesksPresent2.Anchor = System.Windows.Forms.AnchorStyles.Top;
            this.cbDesksPresent2.Location = new System.Drawing.Point(350, 345);
            this.cbDesksPresent2.Name = "cbDesksPresent2";
            this.cbDesksPresent2.Size = new System.Drawing.Size(15, 14);
            this.cbDesksPresent2.TabIndex = 82;
            this.cbDesksPresent2.UseVisualStyleBackColor = true;
            // 
            // tbDesksIDNumber2
            // 
            this.tbDesksIDNumber2.Anchor = System.Windows.Forms.AnchorStyles.Top;
            this.tbDesksIDNumber2.Location = new System.Drawing.Point(180, 342);
            this.tbDesksIDNumber2.Name = "tbDesksIDNumber2";
            this.tbDesksIDNumber2.Size = new System.Drawing.Size(127, 20);
            this.tbDesksIDNumber2.TabIndex = 81;
            // 
            // tbDressersComments2
            // 
            this.tbDressersComments2.Anchor = System.Windows.Forms.AnchorStyles.Top;
            this.tbDressersComments2.Location = new System.Drawing.Point(466, 478);
            this.tbDressersComments2.Name = "tbDressersComments2";
            this.tbDressersComments2.Size = new System.Drawing.Size(177, 20);
            this.tbDressersComments2.TabIndex = 88;
            // 
            // cbDressersReplace2
            // 
            this.cbDressersReplace2.Anchor = System.Windows.Forms.AnchorStyles.Top;
            this.cbDressersReplace2.Location = new System.Drawing.Point(408, 482);
            this.cbDressersReplace2.Name = "cbDressersReplace2";
            this.cbDressersReplace2.Size = new System.Drawing.Size(16, 17);
            this.cbDressersReplace2.TabIndex = 87;
            this.cbDressersReplace2.UseVisualStyleBackColor = true;
            // 
            // cbDressersPresent2
            // 
            this.cbDressersPresent2.Anchor = System.Windows.Forms.AnchorStyles.Top;
            this.cbDressersPresent2.Location = new System.Drawing.Point(350, 483);
            this.cbDressersPresent2.Name = "cbDressersPresent2";
            this.cbDressersPresent2.Size = new System.Drawing.Size(15, 14);
            this.cbDressersPresent2.TabIndex = 86;
            this.cbDressersPresent2.UseVisualStyleBackColor = true;
            // 
            // tbDressersIDNumber2
            // 
            this.tbDressersIDNumber2.Anchor = System.Windows.Forms.AnchorStyles.Top;
            this.tbDressersIDNumber2.Location = new System.Drawing.Point(180, 480);
            this.tbDressersIDNumber2.Name = "tbDressersIDNumber2";
            this.tbDressersIDNumber2.Size = new System.Drawing.Size(127, 20);
            this.tbDressersIDNumber2.TabIndex = 85;
            // 
            // tbMattressComments3
            // 
            this.tbMattressComments3.Anchor = System.Windows.Forms.AnchorStyles.Top;
            this.tbMattressComments3.Location = new System.Drawing.Point(465, 94);
            this.tbMattressComments3.Name = "tbMattressComments3";
            this.tbMattressComments3.Size = new System.Drawing.Size(177, 20);
            this.tbMattressComments3.TabIndex = 92;
            // 
            // cbMattressReplace3
            // 
            this.cbMattressReplace3.Anchor = System.Windows.Forms.AnchorStyles.Top;
            this.cbMattressReplace3.Location = new System.Drawing.Point(407, 98);
            this.cbMattressReplace3.Name = "cbMattressReplace3";
            this.cbMattressReplace3.Size = new System.Drawing.Size(16, 17);
            this.cbMattressReplace3.TabIndex = 91;
            this.cbMattressReplace3.UseVisualStyleBackColor = true;
            // 
            // cbMattressPresent3
            // 
            this.cbMattressPresent3.Anchor = System.Windows.Forms.AnchorStyles.Top;
            this.cbMattressPresent3.Location = new System.Drawing.Point(350, 99);
            this.cbMattressPresent3.Name = "cbMattressPresent3";
            this.cbMattressPresent3.Size = new System.Drawing.Size(15, 14);
            this.cbMattressPresent3.TabIndex = 90;
            this.cbMattressPresent3.UseVisualStyleBackColor = true;
            // 
            // tbMattressIDNumber3
            // 
            this.tbMattressIDNumber3.Anchor = System.Windows.Forms.AnchorStyles.Top;
            this.tbMattressIDNumber3.Location = new System.Drawing.Point(179, 96);
            this.tbMattressIDNumber3.Name = "tbMattressIDNumber3";
            this.tbMattressIDNumber3.Size = new System.Drawing.Size(127, 20);
            this.tbMattressIDNumber3.TabIndex = 89;
            // 
            // tbBedFrameComments3
            // 
            this.tbBedFrameComments3.Anchor = System.Windows.Forms.AnchorStyles.Top;
            this.tbBedFrameComments3.Location = new System.Drawing.Point(465, 232);
            this.tbBedFrameComments3.Name = "tbBedFrameComments3";
            this.tbBedFrameComments3.Size = new System.Drawing.Size(177, 20);
            this.tbBedFrameComments3.TabIndex = 96;
            // 
            // cbBedFrameReplace3
            // 
            this.cbBedFrameReplace3.Anchor = System.Windows.Forms.AnchorStyles.Top;
            this.cbBedFrameReplace3.Location = new System.Drawing.Point(407, 236);
            this.cbBedFrameReplace3.Name = "cbBedFrameReplace3";
            this.cbBedFrameReplace3.Size = new System.Drawing.Size(16, 17);
            this.cbBedFrameReplace3.TabIndex = 95;
            this.cbBedFrameReplace3.UseVisualStyleBackColor = true;
            // 
            // cbBedFramePresent3
            // 
            this.cbBedFramePresent3.Anchor = System.Windows.Forms.AnchorStyles.Top;
            this.cbBedFramePresent3.Location = new System.Drawing.Point(350, 237);
            this.cbBedFramePresent3.Name = "cbBedFramePresent3";
            this.cbBedFramePresent3.Size = new System.Drawing.Size(15, 14);
            this.cbBedFramePresent3.TabIndex = 94;
            this.cbBedFramePresent3.UseVisualStyleBackColor = true;
            // 
            // tbBedFrameIDNumber3
            // 
            this.tbBedFrameIDNumber3.Anchor = System.Windows.Forms.AnchorStyles.Top;
            this.tbBedFrameIDNumber3.Location = new System.Drawing.Point(179, 234);
            this.tbBedFrameIDNumber3.Name = "tbBedFrameIDNumber3";
            this.tbBedFrameIDNumber3.Size = new System.Drawing.Size(127, 20);
            this.tbBedFrameIDNumber3.TabIndex = 93;
            // 
            // tbDesksComments3
            // 
            this.tbDesksComments3.Anchor = System.Windows.Forms.AnchorStyles.Top;
            this.tbDesksComments3.Location = new System.Drawing.Point(466, 362);
            this.tbDesksComments3.Name = "tbDesksComments3";
            this.tbDesksComments3.Size = new System.Drawing.Size(177, 20);
            this.tbDesksComments3.TabIndex = 100;
            // 
            // cbDesksReplace3
            // 
            this.cbDesksReplace3.Anchor = System.Windows.Forms.AnchorStyles.Top;
            this.cbDesksReplace3.Location = new System.Drawing.Point(408, 366);
            this.cbDesksReplace3.Name = "cbDesksReplace3";
            this.cbDesksReplace3.Size = new System.Drawing.Size(16, 17);
            this.cbDesksReplace3.TabIndex = 99;
            this.cbDesksReplace3.UseVisualStyleBackColor = true;
            // 
            // cbDesksPresent3
            // 
            this.cbDesksPresent3.Anchor = System.Windows.Forms.AnchorStyles.Top;
            this.cbDesksPresent3.Location = new System.Drawing.Point(350, 367);
            this.cbDesksPresent3.Name = "cbDesksPresent3";
            this.cbDesksPresent3.Size = new System.Drawing.Size(15, 14);
            this.cbDesksPresent3.TabIndex = 98;
            this.cbDesksPresent3.UseVisualStyleBackColor = true;
            // 
            // tbDesksIDNumber3
            // 
            this.tbDesksIDNumber3.Anchor = System.Windows.Forms.AnchorStyles.Top;
            this.tbDesksIDNumber3.Location = new System.Drawing.Point(180, 364);
            this.tbDesksIDNumber3.Name = "tbDesksIDNumber3";
            this.tbDesksIDNumber3.Size = new System.Drawing.Size(127, 20);
            this.tbDesksIDNumber3.TabIndex = 97;
            // 
            // tbDressersComments3
            // 
            this.tbDressersComments3.Anchor = System.Windows.Forms.AnchorStyles.Top;
            this.tbDressersComments3.Location = new System.Drawing.Point(466, 500);
            this.tbDressersComments3.Name = "tbDressersComments3";
            this.tbDressersComments3.Size = new System.Drawing.Size(177, 20);
            this.tbDressersComments3.TabIndex = 104;
            // 
            // cbDressersReplace3
            // 
            this.cbDressersReplace3.Anchor = System.Windows.Forms.AnchorStyles.Top;
            this.cbDressersReplace3.Location = new System.Drawing.Point(408, 504);
            this.cbDressersReplace3.Name = "cbDressersReplace3";
            this.cbDressersReplace3.Size = new System.Drawing.Size(16, 17);
            this.cbDressersReplace3.TabIndex = 103;
            this.cbDressersReplace3.UseVisualStyleBackColor = true;
            // 
            // cbDressersPresent3
            // 
            this.cbDressersPresent3.Anchor = System.Windows.Forms.AnchorStyles.Top;
            this.cbDressersPresent3.Location = new System.Drawing.Point(351, 505);
            this.cbDressersPresent3.Name = "cbDressersPresent3";
            this.cbDressersPresent3.Size = new System.Drawing.Size(15, 14);
            this.cbDressersPresent3.TabIndex = 102;
            this.cbDressersPresent3.UseVisualStyleBackColor = true;
            // 
            // tbDressersIDNumber3
            // 
            this.tbDressersIDNumber3.Anchor = System.Windows.Forms.AnchorStyles.Top;
            this.tbDressersIDNumber3.Location = new System.Drawing.Point(180, 502);
            this.tbDressersIDNumber3.Name = "tbDressersIDNumber3";
            this.tbDressersIDNumber3.Size = new System.Drawing.Size(127, 20);
            this.tbDressersIDNumber3.TabIndex = 101;
            // 
            // tbMattressComments4
            // 
            this.tbMattressComments4.Anchor = System.Windows.Forms.AnchorStyles.Top;
            this.tbMattressComments4.Location = new System.Drawing.Point(466, 116);
            this.tbMattressComments4.Name = "tbMattressComments4";
            this.tbMattressComments4.Size = new System.Drawing.Size(177, 20);
            this.tbMattressComments4.TabIndex = 108;
            // 
            // cbMattressReplace4
            // 
            this.cbMattressReplace4.Anchor = System.Windows.Forms.AnchorStyles.Top;
            this.cbMattressReplace4.Location = new System.Drawing.Point(408, 120);
            this.cbMattressReplace4.Name = "cbMattressReplace4";
            this.cbMattressReplace4.Size = new System.Drawing.Size(16, 17);
            this.cbMattressReplace4.TabIndex = 107;
            this.cbMattressReplace4.UseVisualStyleBackColor = true;
            // 
            // cbMattressPresent4
            // 
            this.cbMattressPresent4.Anchor = System.Windows.Forms.AnchorStyles.Top;
            this.cbMattressPresent4.Location = new System.Drawing.Point(350, 121);
            this.cbMattressPresent4.Name = "cbMattressPresent4";
            this.cbMattressPresent4.Size = new System.Drawing.Size(15, 14);
            this.cbMattressPresent4.TabIndex = 106;
            this.cbMattressPresent4.UseVisualStyleBackColor = true;
            // 
            // tbMattressIDNumber4
            // 
            this.tbMattressIDNumber4.Anchor = System.Windows.Forms.AnchorStyles.Top;
            this.tbMattressIDNumber4.Location = new System.Drawing.Point(180, 118);
            this.tbMattressIDNumber4.Name = "tbMattressIDNumber4";
            this.tbMattressIDNumber4.Size = new System.Drawing.Size(127, 20);
            this.tbMattressIDNumber4.TabIndex = 105;
            // 
            // tbBedFrameComments4
            // 
            this.tbBedFrameComments4.Anchor = System.Windows.Forms.AnchorStyles.Top;
            this.tbBedFrameComments4.Location = new System.Drawing.Point(465, 254);
            this.tbBedFrameComments4.Name = "tbBedFrameComments4";
            this.tbBedFrameComments4.Size = new System.Drawing.Size(177, 20);
            this.tbBedFrameComments4.TabIndex = 112;
            // 
            // cbBedFrameReplace4
            // 
            this.cbBedFrameReplace4.Anchor = System.Windows.Forms.AnchorStyles.Top;
            this.cbBedFrameReplace4.Location = new System.Drawing.Point(407, 258);
            this.cbBedFrameReplace4.Name = "cbBedFrameReplace4";
            this.cbBedFrameReplace4.Size = new System.Drawing.Size(16, 17);
            this.cbBedFrameReplace4.TabIndex = 111;
            this.cbBedFrameReplace4.UseVisualStyleBackColor = true;
            // 
            // cbBedFramePresent4
            // 
            this.cbBedFramePresent4.Anchor = System.Windows.Forms.AnchorStyles.Top;
            this.cbBedFramePresent4.Location = new System.Drawing.Point(350, 259);
            this.cbBedFramePresent4.Name = "cbBedFramePresent4";
            this.cbBedFramePresent4.Size = new System.Drawing.Size(15, 14);
            this.cbBedFramePresent4.TabIndex = 110;
            this.cbBedFramePresent4.UseVisualStyleBackColor = true;
            // 
            // tbBedFrameIDNumber4
            // 
            this.tbBedFrameIDNumber4.Anchor = System.Windows.Forms.AnchorStyles.Top;
            this.tbBedFrameIDNumber4.Location = new System.Drawing.Point(179, 256);
            this.tbBedFrameIDNumber4.Name = "tbBedFrameIDNumber4";
            this.tbBedFrameIDNumber4.Size = new System.Drawing.Size(127, 20);
            this.tbBedFrameIDNumber4.TabIndex = 109;
            // 
            // tbDesksComments4
            // 
            this.tbDesksComments4.Anchor = System.Windows.Forms.AnchorStyles.Top;
            this.tbDesksComments4.Location = new System.Drawing.Point(466, 384);
            this.tbDesksComments4.Name = "tbDesksComments4";
            this.tbDesksComments4.Size = new System.Drawing.Size(177, 20);
            this.tbDesksComments4.TabIndex = 116;
            // 
            // cbDesksReplace4
            // 
            this.cbDesksReplace4.Anchor = System.Windows.Forms.AnchorStyles.Top;
            this.cbDesksReplace4.Location = new System.Drawing.Point(408, 388);
            this.cbDesksReplace4.Name = "cbDesksReplace4";
            this.cbDesksReplace4.Size = new System.Drawing.Size(16, 17);
            this.cbDesksReplace4.TabIndex = 115;
            this.cbDesksReplace4.UseVisualStyleBackColor = true;
            // 
            // cbDesksPresent4
            // 
            this.cbDesksPresent4.Anchor = System.Windows.Forms.AnchorStyles.Top;
            this.cbDesksPresent4.Location = new System.Drawing.Point(350, 389);
            this.cbDesksPresent4.Name = "cbDesksPresent4";
            this.cbDesksPresent4.Size = new System.Drawing.Size(15, 14);
            this.cbDesksPresent4.TabIndex = 114;
            this.cbDesksPresent4.UseVisualStyleBackColor = true;
            // 
            // tbDesksIDNumber4
            // 
            this.tbDesksIDNumber4.Anchor = System.Windows.Forms.AnchorStyles.Top;
            this.tbDesksIDNumber4.Location = new System.Drawing.Point(180, 386);
            this.tbDesksIDNumber4.Name = "tbDesksIDNumber4";
            this.tbDesksIDNumber4.Size = new System.Drawing.Size(127, 20);
            this.tbDesksIDNumber4.TabIndex = 113;
            // 
            // tbDressersComments4
            // 
            this.tbDressersComments4.Anchor = System.Windows.Forms.AnchorStyles.Top;
            this.tbDressersComments4.Location = new System.Drawing.Point(466, 523);
            this.tbDressersComments4.Name = "tbDressersComments4";
            this.tbDressersComments4.Size = new System.Drawing.Size(177, 20);
            this.tbDressersComments4.TabIndex = 120;
            // 
            // cbDressersReplace4
            // 
            this.cbDressersReplace4.Anchor = System.Windows.Forms.AnchorStyles.Top;
            this.cbDressersReplace4.Location = new System.Drawing.Point(408, 527);
            this.cbDressersReplace4.Name = "cbDressersReplace4";
            this.cbDressersReplace4.Size = new System.Drawing.Size(16, 17);
            this.cbDressersReplace4.TabIndex = 119;
            this.cbDressersReplace4.UseVisualStyleBackColor = true;
            // 
            // cbDressersPresent4
            // 
            this.cbDressersPresent4.Anchor = System.Windows.Forms.AnchorStyles.Top;
            this.cbDressersPresent4.Location = new System.Drawing.Point(351, 528);
            this.cbDressersPresent4.Name = "cbDressersPresent4";
            this.cbDressersPresent4.Size = new System.Drawing.Size(15, 14);
            this.cbDressersPresent4.TabIndex = 118;
            this.cbDressersPresent4.UseVisualStyleBackColor = true;
            // 
            // tbDressersIDNumebr4
            // 
            this.tbDressersIDNumebr4.Anchor = System.Windows.Forms.AnchorStyles.Top;
            this.tbDressersIDNumebr4.Location = new System.Drawing.Point(180, 525);
            this.tbDressersIDNumebr4.Name = "tbDressersIDNumebr4";
            this.tbDressersIDNumebr4.Size = new System.Drawing.Size(127, 20);
            this.tbDressersIDNumebr4.TabIndex = 117;
            // 
            // UpdateRoomInventory__4_Person
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.SystemColors.ControlDark;
            this.ClientSize = new System.Drawing.Size(661, 692);
            this.Controls.Add(this.tbDressersComments4);
            this.Controls.Add(this.cbDressersReplace4);
            this.Controls.Add(this.cbDressersPresent4);
            this.Controls.Add(this.tbDressersIDNumebr4);
            this.Controls.Add(this.tbDesksComments4);
            this.Controls.Add(this.cbDesksReplace4);
            this.Controls.Add(this.cbDesksPresent4);
            this.Controls.Add(this.tbDesksIDNumber4);
            this.Controls.Add(this.tbBedFrameComments4);
            this.Controls.Add(this.cbBedFrameReplace4);
            this.Controls.Add(this.cbBedFramePresent4);
            this.Controls.Add(this.tbBedFrameIDNumber4);
            this.Controls.Add(this.tbMattressComments4);
            this.Controls.Add(this.cbMattressReplace4);
            this.Controls.Add(this.cbMattressPresent4);
            this.Controls.Add(this.tbMattressIDNumber4);
            this.Controls.Add(this.tbDressersComments3);
            this.Controls.Add(this.cbDressersReplace3);
            this.Controls.Add(this.cbDressersPresent3);
            this.Controls.Add(this.tbDressersIDNumber3);
            this.Controls.Add(this.tbDesksComments3);
            this.Controls.Add(this.cbDesksReplace3);
            this.Controls.Add(this.cbDesksPresent3);
            this.Controls.Add(this.tbDesksIDNumber3);
            this.Controls.Add(this.tbBedFrameComments3);
            this.Controls.Add(this.cbBedFrameReplace3);
            this.Controls.Add(this.cbBedFramePresent3);
            this.Controls.Add(this.tbBedFrameIDNumber3);
            this.Controls.Add(this.tbMattressComments3);
            this.Controls.Add(this.cbMattressReplace3);
            this.Controls.Add(this.cbMattressPresent3);
            this.Controls.Add(this.tbMattressIDNumber3);
            this.Controls.Add(this.tbDressersComments2);
            this.Controls.Add(this.cbDressersReplace2);
            this.Controls.Add(this.cbDressersPresent2);
            this.Controls.Add(this.tbDressersIDNumber2);
            this.Controls.Add(this.tbDesksComments2);
            this.Controls.Add(this.cbDesksReplace2);
            this.Controls.Add(this.cbDesksPresent2);
            this.Controls.Add(this.tbDesksIDNumber2);
            this.Controls.Add(this.tbBedFrameComments2);
            this.Controls.Add(this.cbBedFrameReplace2);
            this.Controls.Add(this.cbBedFramePresent2);
            this.Controls.Add(this.tbBedFrameIDNumber2);
            this.Controls.Add(this.tbMattressComments2);
            this.Controls.Add(this.cbMattressReplace2);
            this.Controls.Add(this.cbMattressPresent2);
            this.Controls.Add(this.tbMattressIDNumber2);
            this.Controls.Add(this.bnSubmit);
            this.Controls.Add(this.tbRoomComments);
            this.Controls.Add(this.Label24);
            this.Controls.Add(this.dlTrashCanQuantity);
            this.Controls.Add(this.Label23);
            this.Controls.Add(this.Label22);
            this.Controls.Add(this.dlChairsQuantity);
            this.Controls.Add(this.Label17);
            this.Controls.Add(this.tbDressersComments);
            this.Controls.Add(this.Label18);
            this.Controls.Add(this.cbDressersReplace);
            this.Controls.Add(this.Label19);
            this.Controls.Add(this.cbDressersPresent);
            this.Controls.Add(this.tbDressersIdNumber);
            this.Controls.Add(this.Label20);
            this.Controls.Add(this.Label21);
            this.Controls.Add(this.Label12);
            this.Controls.Add(this.tbDeskComments);
            this.Controls.Add(this.Label13);
            this.Controls.Add(this.cbDeskReplace);
            this.Controls.Add(this.Label14);
            this.Controls.Add(this.cbDeskPresent);
            this.Controls.Add(this.tbDeskIDNumber);
            this.Controls.Add(this.Label15);
            this.Controls.Add(this.Label16);
            this.Controls.Add(this.Label11);
            this.Controls.Add(this.Label7);
            this.Controls.Add(this.tbBedFrameComments);
            this.Controls.Add(this.Label8);
            this.Controls.Add(this.cbBedFrameReplace);
            this.Controls.Add(this.Label9);
            this.Controls.Add(this.cbBedFramePresent);
            this.Controls.Add(this.tbBedFrameIDNumber);
            this.Controls.Add(this.Label10);
            this.Controls.Add(this.Label6);
            this.Controls.Add(this.Label5);
            this.Controls.Add(this.tbMattressComments);
            this.Controls.Add(this.Label4);
            this.Controls.Add(this.cbMattressReplace);
            this.Controls.Add(this.Label3);
            this.Controls.Add(this.cbMattressPresent);
            this.Controls.Add(this.tbMattressIDNumber);
            this.Controls.Add(this.Label2);
            this.Controls.Add(this.Label1);
            this.Controls.Add(this.llExit);
            this.Controls.Add(this.llManageUsers);
            this.Controls.Add(this.llPurchaseRequisitions);
            this.Controls.Add(this.llRunViewReports);
            this.Controls.Add(this.llLogOut);
            this.Controls.Add(this.llUpdateRoomInventory);
            this.Controls.Add(this.llHome);
            this.Controls.Add(this.Splitter1);
            this.MaximizeBox = false;
            this.MaximumSize = new System.Drawing.Size(677, 730);
            this.MinimumSize = new System.Drawing.Size(677, 730);
            this.Name = "UpdateRoomInventory__4_Person";
            this.Text = "Update Room Inventory- 4 Person";
            this.ResumeLayout(false);
            this.PerformLayout();

        }
        internal System.Windows.Forms.LinkLabel llManageUsers;
        internal System.Windows.Forms.LinkLabel llPurchaseRequisitions;
        internal System.Windows.Forms.LinkLabel llRunViewReports;
        internal System.Windows.Forms.LinkLabel llLogOut;
        internal System.Windows.Forms.LinkLabel llUpdateRoomInventory;
        internal System.Windows.Forms.LinkLabel llHome;
        internal System.Windows.Forms.Splitter Splitter1;
        internal System.Windows.Forms.LinkLabel llExit;
        internal System.Windows.Forms.Label Label1;
        internal System.Windows.Forms.Label Label2;
        internal System.Windows.Forms.TextBox tbMattressIDNumber;
        internal System.Windows.Forms.CheckBox cbMattressPresent;
        internal System.Windows.Forms.Label Label3;
        internal System.Windows.Forms.Label Label4;
        internal System.Windows.Forms.CheckBox cbMattressReplace;
        internal System.Windows.Forms.TextBox tbMattressComments;
        internal System.Windows.Forms.Label Label5;
        internal System.Windows.Forms.Label Label6;
        internal System.Windows.Forms.Label Label7;
        internal System.Windows.Forms.TextBox tbBedFrameComments;
        internal System.Windows.Forms.Label Label8;
        internal System.Windows.Forms.CheckBox cbBedFrameReplace;
        internal System.Windows.Forms.Label Label9;
        internal System.Windows.Forms.CheckBox cbBedFramePresent;
        internal System.Windows.Forms.TextBox tbBedFrameIDNumber;
        internal System.Windows.Forms.Label Label10;
        internal System.Windows.Forms.Label Label11;
        internal System.Windows.Forms.Label Label12;
        internal System.Windows.Forms.TextBox tbDeskComments;
        internal System.Windows.Forms.Label Label13;
        internal System.Windows.Forms.CheckBox cbDeskReplace;
        internal System.Windows.Forms.Label Label14;
        internal System.Windows.Forms.CheckBox cbDeskPresent;
        internal System.Windows.Forms.TextBox tbDeskIDNumber;
        internal System.Windows.Forms.Label Label15;
        internal System.Windows.Forms.Label Label16;
        internal System.Windows.Forms.Label Label17;
        internal System.Windows.Forms.TextBox tbDressersComments;
        internal System.Windows.Forms.Label Label18;
        internal System.Windows.Forms.CheckBox cbDressersReplace;
        internal System.Windows.Forms.Label Label19;
        internal System.Windows.Forms.CheckBox cbDressersPresent;
        internal System.Windows.Forms.TextBox tbDressersIdNumber;
        internal System.Windows.Forms.Label Label20;
        internal System.Windows.Forms.Label Label21;
        internal System.Windows.Forms.ComboBox dlChairsQuantity;
        internal System.Windows.Forms.Label Label22;
        internal System.Windows.Forms.ComboBox dlTrashCanQuantity;
        internal System.Windows.Forms.Label Label23;
        internal System.Windows.Forms.Label Label24;
        internal System.Windows.Forms.TextBox tbRoomComments;
        internal System.Windows.Forms.Button bnSubmit;
        internal System.Windows.Forms.TextBox tbMattressComments2;
        internal System.Windows.Forms.CheckBox cbMattressReplace2;
        internal System.Windows.Forms.CheckBox cbMattressPresent2;
        internal System.Windows.Forms.TextBox tbMattressIDNumber2;
        internal System.Windows.Forms.TextBox tbBedFrameComments2;
        internal System.Windows.Forms.CheckBox cbBedFrameReplace2;
        internal System.Windows.Forms.CheckBox cbBedFramePresent2;
        internal System.Windows.Forms.TextBox tbBedFrameIDNumber2;
        internal System.Windows.Forms.TextBox tbDesksComments2;
        internal System.Windows.Forms.CheckBox cbDesksReplace2;
        internal System.Windows.Forms.CheckBox cbDesksPresent2;
        internal System.Windows.Forms.TextBox tbDesksIDNumber2;
        internal System.Windows.Forms.TextBox tbDressersComments2;
        internal System.Windows.Forms.CheckBox cbDressersReplace2;
        internal System.Windows.Forms.CheckBox cbDressersPresent2;
        internal System.Windows.Forms.TextBox tbDressersIDNumber2;
        internal System.Windows.Forms.TextBox tbMattressComments3;
        internal System.Windows.Forms.CheckBox cbMattressReplace3;
        internal System.Windows.Forms.CheckBox cbMattressPresent3;
        internal System.Windows.Forms.TextBox tbMattressIDNumber3;
        internal System.Windows.Forms.TextBox tbBedFrameComments3;
        internal System.Windows.Forms.CheckBox cbBedFrameReplace3;
        internal System.Windows.Forms.CheckBox cbBedFramePresent3;
        internal System.Windows.Forms.TextBox tbBedFrameIDNumber3;
        internal System.Windows.Forms.TextBox tbDesksComments3;
        internal System.Windows.Forms.CheckBox cbDesksReplace3;
        internal System.Windows.Forms.CheckBox cbDesksPresent3;
        internal System.Windows.Forms.TextBox tbDesksIDNumber3;
        internal System.Windows.Forms.TextBox tbDressersComments3;
        internal System.Windows.Forms.CheckBox cbDressersReplace3;
        internal System.Windows.Forms.CheckBox cbDressersPresent3;
        internal System.Windows.Forms.TextBox tbDressersIDNumber3;
        internal System.Windows.Forms.TextBox tbMattressComments4;
        internal System.Windows.Forms.CheckBox cbMattressReplace4;
        internal System.Windows.Forms.CheckBox cbMattressPresent4;
        internal System.Windows.Forms.TextBox tbMattressIDNumber4;
        internal System.Windows.Forms.TextBox tbBedFrameComments4;
        internal System.Windows.Forms.CheckBox cbBedFrameReplace4;
        internal System.Windows.Forms.CheckBox cbBedFramePresent4;
        internal System.Windows.Forms.TextBox tbBedFrameIDNumber4;
        internal System.Windows.Forms.TextBox tbDesksComments4;
        internal System.Windows.Forms.CheckBox cbDesksReplace4;
        internal System.Windows.Forms.CheckBox cbDesksPresent4;
        internal System.Windows.Forms.TextBox tbDesksIDNumber4;
        internal System.Windows.Forms.TextBox tbDressersComments4;
        internal System.Windows.Forms.CheckBox cbDressersReplace4;
        internal System.Windows.Forms.CheckBox cbDressersPresent4;
        internal System.Windows.Forms.TextBox tbDressersIDNumebr4;
    }
}