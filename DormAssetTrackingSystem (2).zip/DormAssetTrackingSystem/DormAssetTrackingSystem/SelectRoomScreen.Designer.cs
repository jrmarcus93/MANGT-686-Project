﻿
using Microsoft.VisualBasic;
using System;
using System.Collections;
using System.Collections.Generic;
using System.Data;
using System.Diagnostics;
namespace DormAssetTrackingSystem
{
    [Microsoft.VisualBasic.CompilerServices.DesignerGenerated()]
    partial class SelectRoomScreen : System.Windows.Forms.Form
    {

        //Form overrides dispose to clean up the component list.
        [System.Diagnostics.DebuggerNonUserCode()]
        protected override void Dispose(bool disposing)
        {
            try
            {
                if (disposing && components != null)
                {
                    components.Dispose();
                }
            }
            finally
            {
                base.Dispose(disposing);
            }
        }

        //Required by the Windows Form Designer

        private System.ComponentModel.IContainer components;
        //NOTE: The following procedure is required by the Windows Form Designer
        //It can be modified using the Windows Form Designer.  
        //Do not modify it using the code editor.
        [System.Diagnostics.DebuggerStepThrough()]
        private void InitializeComponent()
        {
            this.Label1 = new System.Windows.Forms.Label();
            this.llHousingComplex = new System.Windows.Forms.ComboBox();
            this.Label2 = new System.Windows.Forms.Label();
            this.llBuilding = new System.Windows.Forms.ComboBox();
            this.Label3 = new System.Windows.Forms.Label();
            this.llManageUsers = new System.Windows.Forms.LinkLabel();
            this.llPurchaseRequisition = new System.Windows.Forms.LinkLabel();
            this.llRunViewReports = new System.Windows.Forms.LinkLabel();
            this.llLogOut = new System.Windows.Forms.LinkLabel();
            this.llUpdateRoomInventory = new System.Windows.Forms.LinkLabel();
            this.llHome = new System.Windows.Forms.LinkLabel();
            this.Splitter1 = new System.Windows.Forms.Splitter();
            this.dlFloorNumber = new System.Windows.Forms.ComboBox();
            this.dlRoomNumber = new System.Windows.Forms.ComboBox();
            this.Label4 = new System.Windows.Forms.Label();
            this.bnUpdateInventory = new System.Windows.Forms.Button();
            this.llExit = new System.Windows.Forms.LinkLabel();
            this.SuspendLayout();
            // 
            // Label1
            // 
            this.Label1.AutoSize = true;
            this.Label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Label1.Location = new System.Drawing.Point(380, 58);
            this.Label1.Margin = new System.Windows.Forms.Padding(6, 0, 6, 0);
            this.Label1.Name = "Label1";
            this.Label1.Size = new System.Drawing.Size(318, 31);
            this.Label1.TabIndex = 4;
            this.Label1.Text = "Select Housing Complex:";
            // 
            // llHousingComplex
            // 
            this.llHousingComplex.FormattingEnabled = true;
            this.llHousingComplex.Location = new System.Drawing.Point(352, 96);
            this.llHousingComplex.Margin = new System.Windows.Forms.Padding(6);
            this.llHousingComplex.Name = "llHousingComplex";
            this.llHousingComplex.Size = new System.Drawing.Size(396, 33);
            this.llHousingComplex.TabIndex = 5;
            // 
            // Label2
            // 
            this.Label2.AutoSize = true;
            this.Label2.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F);
            this.Label2.Location = new System.Drawing.Point(440, 160);
            this.Label2.Margin = new System.Windows.Forms.Padding(6, 0, 6, 0);
            this.Label2.Name = "Label2";
            this.Label2.Size = new System.Drawing.Size(201, 31);
            this.Label2.TabIndex = 6;
            this.Label2.Text = "Select Building:";
            // 
            // llBuilding
            // 
            this.llBuilding.Enabled = false;
            this.llBuilding.FormattingEnabled = true;
            this.llBuilding.Location = new System.Drawing.Point(352, 198);
            this.llBuilding.Margin = new System.Windows.Forms.Padding(6);
            this.llBuilding.Name = "llBuilding";
            this.llBuilding.Size = new System.Drawing.Size(396, 33);
            this.llBuilding.TabIndex = 7;
            // 
            // Label3
            // 
            this.Label3.AutoSize = true;
            this.Label3.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F);
            this.Label3.Location = new System.Drawing.Point(406, 267);
            this.Label3.Margin = new System.Windows.Forms.Padding(6, 0, 6, 0);
            this.Label3.Name = "Label3";
            this.Label3.Size = new System.Drawing.Size(270, 31);
            this.Label3.TabIndex = 8;
            this.Label3.Text = "Select Floor Number:";
            // 
            // llManageUsers
            // 
            this.llManageUsers.AutoSize = true;
            this.llManageUsers.BackColor = System.Drawing.Color.Indigo;
            this.llManageUsers.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F);
            this.llManageUsers.LinkColor = System.Drawing.Color.White;
            this.llManageUsers.Location = new System.Drawing.Point(2, 277);
            this.llManageUsers.Margin = new System.Windows.Forms.Padding(6, 0, 6, 0);
            this.llManageUsers.Name = "llManageUsers";
            this.llManageUsers.Size = new System.Drawing.Size(190, 31);
            this.llManageUsers.TabIndex = 20;
            this.llManageUsers.TabStop = true;
            this.llManageUsers.Text = "Manage Users";
            // 
            // llPurchaseRequisition
            // 
            this.llPurchaseRequisition.AutoSize = true;
            this.llPurchaseRequisition.BackColor = System.Drawing.Color.Indigo;
            this.llPurchaseRequisition.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F);
            this.llPurchaseRequisition.LinkColor = System.Drawing.Color.White;
            this.llPurchaseRequisition.Location = new System.Drawing.Point(4, 221);
            this.llPurchaseRequisition.Margin = new System.Windows.Forms.Padding(6, 0, 6, 0);
            this.llPurchaseRequisition.Name = "llPurchaseRequisition";
            this.llPurchaseRequisition.Size = new System.Drawing.Size(271, 31);
            this.llPurchaseRequisition.TabIndex = 19;
            this.llPurchaseRequisition.TabStop = true;
            this.llPurchaseRequisition.Text = "Purchase Requisition";
            // 
            // llRunViewReports
            // 
            this.llRunViewReports.AutoSize = true;
            this.llRunViewReports.BackColor = System.Drawing.Color.Indigo;
            this.llRunViewReports.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F);
            this.llRunViewReports.LinkColor = System.Drawing.Color.White;
            this.llRunViewReports.Location = new System.Drawing.Point(2, 163);
            this.llRunViewReports.Margin = new System.Windows.Forms.Padding(6, 0, 6, 0);
            this.llRunViewReports.Name = "llRunViewReports";
            this.llRunViewReports.Size = new System.Drawing.Size(234, 31);
            this.llRunViewReports.TabIndex = 18;
            this.llRunViewReports.TabStop = true;
            this.llRunViewReports.Text = "Run/View Reports";
            // 
            // llLogOut
            // 
            this.llLogOut.AutoSize = true;
            this.llLogOut.BackColor = System.Drawing.Color.Indigo;
            this.llLogOut.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F);
            this.llLogOut.LinkColor = System.Drawing.Color.White;
            this.llLogOut.Location = new System.Drawing.Point(2, 521);
            this.llLogOut.Margin = new System.Windows.Forms.Padding(6, 0, 6, 0);
            this.llLogOut.Name = "llLogOut";
            this.llLogOut.Size = new System.Drawing.Size(110, 31);
            this.llLogOut.TabIndex = 17;
            this.llLogOut.TabStop = true;
            this.llLogOut.Text = "Log Out";
            // 
            // llUpdateRoomInventory
            // 
            this.llUpdateRoomInventory.AutoSize = true;
            this.llUpdateRoomInventory.BackColor = System.Drawing.Color.Indigo;
            this.llUpdateRoomInventory.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F);
            this.llUpdateRoomInventory.LinkColor = System.Drawing.Color.White;
            this.llUpdateRoomInventory.Location = new System.Drawing.Point(2, 73);
            this.llUpdateRoomInventory.Margin = new System.Windows.Forms.Padding(6, 0, 6, 0);
            this.llUpdateRoomInventory.Name = "llUpdateRoomInventory";
            this.llUpdateRoomInventory.Size = new System.Drawing.Size(188, 62);
            this.llUpdateRoomInventory.TabIndex = 16;
            this.llUpdateRoomInventory.TabStop = true;
            this.llUpdateRoomInventory.Text = "Update Room \r\nInventory";
            // 
            // llHome
            // 
            this.llHome.AutoSize = true;
            this.llHome.BackColor = System.Drawing.Color.Indigo;
            this.llHome.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F);
            this.llHome.LinkColor = System.Drawing.Color.White;
            this.llHome.Location = new System.Drawing.Point(2, 17);
            this.llHome.Margin = new System.Windows.Forms.Padding(6, 0, 6, 0);
            this.llHome.Name = "llHome";
            this.llHome.Size = new System.Drawing.Size(86, 31);
            this.llHome.TabIndex = 15;
            this.llHome.TabStop = true;
            this.llHome.Text = "Home";
            // 
            // Splitter1
            // 
            this.Splitter1.BackColor = System.Drawing.Color.Indigo;
            this.Splitter1.Location = new System.Drawing.Point(0, 0);
            this.Splitter1.Margin = new System.Windows.Forms.Padding(6);
            this.Splitter1.Name = "Splitter1";
            this.Splitter1.Size = new System.Drawing.Size(302, 604);
            this.Splitter1.TabIndex = 14;
            this.Splitter1.TabStop = false;
            // 
            // dlFloorNumber
            // 
            this.dlFloorNumber.FormattingEnabled = true;
            this.dlFloorNumber.Location = new System.Drawing.Point(352, 312);
            this.dlFloorNumber.Margin = new System.Windows.Forms.Padding(6);
            this.dlFloorNumber.Name = "dlFloorNumber";
            this.dlFloorNumber.Size = new System.Drawing.Size(396, 33);
            this.dlFloorNumber.TabIndex = 21;
            // 
            // dlRoomNumber
            // 
            this.dlRoomNumber.FormattingEnabled = true;
            this.dlRoomNumber.Location = new System.Drawing.Point(352, 421);
            this.dlRoomNumber.Margin = new System.Windows.Forms.Padding(6);
            this.dlRoomNumber.Name = "dlRoomNumber";
            this.dlRoomNumber.Size = new System.Drawing.Size(396, 33);
            this.dlRoomNumber.TabIndex = 23;
            // 
            // Label4
            // 
            this.Label4.AutoSize = true;
            this.Label4.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F);
            this.Label4.Location = new System.Drawing.Point(406, 377);
            this.Label4.Margin = new System.Windows.Forms.Padding(6, 0, 6, 0);
            this.Label4.Name = "Label4";
            this.Label4.Size = new System.Drawing.Size(280, 31);
            this.Label4.TabIndex = 22;
            this.Label4.Text = "Select Room Number:";
            // 
            // bnUpdateInventory
            // 
            this.bnUpdateInventory.BackColor = System.Drawing.SystemColors.ControlLight;
            this.bnUpdateInventory.Location = new System.Drawing.Point(452, 490);
            this.bnUpdateInventory.Margin = new System.Windows.Forms.Padding(6);
            this.bnUpdateInventory.Name = "bnUpdateInventory";
            this.bnUpdateInventory.Size = new System.Drawing.Size(212, 44);
            this.bnUpdateInventory.TabIndex = 24;
            this.bnUpdateInventory.Text = "Update Inventory";
            this.bnUpdateInventory.UseVisualStyleBackColor = false;
            // 
            // llExit
            // 
            this.llExit.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.llExit.AutoSize = true;
            this.llExit.BackColor = System.Drawing.Color.Indigo;
            this.llExit.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F);
            this.llExit.LinkColor = System.Drawing.Color.White;
            this.llExit.Location = new System.Drawing.Point(2, 554);
            this.llExit.Margin = new System.Windows.Forms.Padding(6, 0, 6, 0);
            this.llExit.Name = "llExit";
            this.llExit.Size = new System.Drawing.Size(59, 31);
            this.llExit.TabIndex = 25;
            this.llExit.TabStop = true;
            this.llExit.Text = "Exit";
            // 
            // SelectRoomScreen
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(12F, 25F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.SystemColors.ControlDark;
            this.ClientSize = new System.Drawing.Size(812, 604);
            this.Controls.Add(this.llExit);
            this.Controls.Add(this.bnUpdateInventory);
            this.Controls.Add(this.dlRoomNumber);
            this.Controls.Add(this.Label4);
            this.Controls.Add(this.dlFloorNumber);
            this.Controls.Add(this.llManageUsers);
            this.Controls.Add(this.llPurchaseRequisition);
            this.Controls.Add(this.llRunViewReports);
            this.Controls.Add(this.llLogOut);
            this.Controls.Add(this.llUpdateRoomInventory);
            this.Controls.Add(this.llHome);
            this.Controls.Add(this.Splitter1);
            this.Controls.Add(this.Label3);
            this.Controls.Add(this.llBuilding);
            this.Controls.Add(this.Label2);
            this.Controls.Add(this.llHousingComplex);
            this.Controls.Add(this.Label1);
            this.Enabled = false;
            this.Margin = new System.Windows.Forms.Padding(6);
            this.Name = "SelectRoomScreen";
            this.Text = "Update Room Inventory";
            this.ResumeLayout(false);
            this.PerformLayout();

        }
        internal System.Windows.Forms.Label Label1;
        internal System.Windows.Forms.ComboBox llHousingComplex;
        internal System.Windows.Forms.Label Label2;
        internal System.Windows.Forms.ComboBox llBuilding;
        internal System.Windows.Forms.Label Label3;
        internal System.Windows.Forms.LinkLabel llManageUsers;
        internal System.Windows.Forms.LinkLabel llPurchaseRequisition;
        internal System.Windows.Forms.LinkLabel llRunViewReports;
        internal System.Windows.Forms.LinkLabel llLogOut;
        internal System.Windows.Forms.LinkLabel llUpdateRoomInventory;
        internal System.Windows.Forms.LinkLabel llHome;
        internal System.Windows.Forms.Splitter Splitter1;
        internal System.Windows.Forms.ComboBox dlFloorNumber;
        internal System.Windows.Forms.ComboBox dlRoomNumber;
        internal System.Windows.Forms.Label Label4;
        internal System.Windows.Forms.Button bnUpdateInventory;
        internal System.Windows.Forms.LinkLabel llExit;
    }
}