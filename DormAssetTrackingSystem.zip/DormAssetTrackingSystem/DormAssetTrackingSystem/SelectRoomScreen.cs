﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using IBM.Data.DB2;

namespace DormAssetTrackingSystem
{
    public partial class SelectRoomScreen : Form
    {
        DB2Connection conn;

        public SelectRoomScreen()
        {
            InitializeComponent();

            //create database connection
            conn = new DB2Connection();
            conn.ConnectionString = "Server=nimitz.cba.ksu.edu:50000;Database=Group1;UID=group1;PWD=Grp1313;";
            conn.Open();

            //initialize values in first 2 combo boxes. Others will initiate once values are chosen.
            InitializeDropdown(dlHousingComplex, "SELECT DISTINCT COMMUNITY FROM ROOM");
            InitializeDropdown(dlBuilding, "SELECT DISTINCT BUILDING FROM ROOM");

            conn.Close();
        }

        private void bnUpdateInventory_Click(object sender, EventArgs e)
        {
            int numPeople = 0;

            //set up query to determine what type of room was selected
            DB2Command getNum = new DB2Command("SELECT NUM_PEOPLE FROM ROOM WHERE BUILDING = " + dlBuilding.SelectedValue.ToString() + "AND ROOM_NUM = " + dlRoomNumber.SelectedValue.ToString());
            DB2DataReader numReader = getNum.ExecuteReader();

            if (numReader.Read())
            {
                numPeople = numReader.GetInt32(0);
            }

            //open the corresponding form
            if (numPeople == 1)
            {
                UpdateRoomInventory__1_Person ur1 = new UpdateRoomInventory__1_Person();
                ur1.ShowDialog();
            }
            else if (numPeople == 2)
            {
                UpdateRoomInventory__2_Person ur2 = new UpdateRoomInventory__2_Person();
                ur2.ShowDialog();
            }
            else if (numPeople == 3)
            {
                UpdateRoomInventory__3_Person ur3 = new UpdateRoomInventory__3_Person();
                ur3.ShowDialog();
            }
            else if (numPeople == 4)
            {
                UpdateRoomInventory__4_Person ur4 = new UpdateRoomInventory__4_Person();
                ur4.ShowDialog();
            }
            else
            {
                //error
            }
        }

        private void InitializeDropdown(ComboBox dl, string query)
        {
            //set up database query
            DB2Command cmdQuery = new DB2Command(query, conn);
            DB2DataReader reader = cmdQuery.ExecuteReader();

            //add each item to the given combo box
            while (reader.Read())
            {
                dl.Items.Add(reader.GetString(0));
            }
            reader.Close();
        }

        private void dlHousingComplex_SelectedIndexChanged(object sender, EventArgs e)
        {
            //change the items listed in the building combo box to match the community
            conn.Open();
            dlBuilding.Items.Clear();
            InitializeDropdown(dlBuilding, "SELECT DISTINCT BUILDING FROM ROOM WHERE COMMUNITY = " + dlHousingComplex.SelectedValue.ToString());
            conn.Close();
        }

        private void dlBuilding_SelectedIndexChanged(object sender, EventArgs e)
        {
            //initialize or change the items listed in the floor and room combo boxes to match the building
            conn.Open();
            dlFloorNumber.Items.Clear();
            dlRoomNumber.Items.Clear();
            InitializeDropdown(dlFloorNumber, "SELECT DISTINCT FLOOR FROM ROOM WHERE BUILDING = " + dlBuilding.SelectedValue.ToString());
            InitializeDropdown(dlRoomNumber, "SELECT DISTINCT ROOM_NUM FROM ROOM WHERE BUILDING = " + dlBuilding.SelectedValue.ToString());
            conn.Close();
        }

        private void dlFloorNumber_SelectedIndexChanged(object sender, EventArgs e)
        {
            //change the items in the room combo box to match the floor
            conn.Open();
            dlRoomNumber.Items.Clear();
            InitializeDropdown(dlRoomNumber, "SELECT DISTINCT ROOM_NUM FROM ROOM WHERE BUILDING = " + dlBuilding.SelectedValue.ToString() + " AND FLOOR = " + dlFloorNumber.SelectedValue.ToString());
            conn.Close();
        }
    }
}
