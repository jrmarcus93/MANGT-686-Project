﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace DormAssetTrackingSystem
{
    public partial class HomeScreen : Form
    {
        public HomeScreen(string user)
        {
            InitializeComponent();
            //Personalize welcome label
            laWelcome.Text = "Welcome, " + user + "!";
            //Insert PctureBox image
            //PictureBox1.Image = 
        }

        private void llUpdateRoomInventory_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
        {
            //navigate to the select room screen to update inventory
            //hide home screen until the select room screen is closed
            SelectRoomScreen srs = new SelectRoomScreen();
            this.Hide();
            srs.Closed += (s, args) => this.Show();
            srs.Show();
        }

        private void llRunViewReports_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
        {
            //navigate to the reports screen
            //hide home screen until the reports screen is closed
            ReportsScreen rs = new ReportsScreen();
            this.Hide();
            rs.Closed += (s, args) => this.Show();
            rs.Show();
        }

        private void llPurchaseReq_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
        {
            //navigate to the purchase requisition screen
            //hide home screen until the purchase requisition screen is closed
            PurchaseRequisition pr = new PurchaseRequisition();
            this.Hide();
            pr.Closed += (s, args) => this.Show();
            pr.Show();
        }

        private void llManageUser_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
        {
            //navigate to the user management screen
            //hide home screen until the manage user screen is closed.
        }

        private void llLogOut_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
        {
            Application.Restart();
        }

        private void llExit_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
        {
            Application.Exit();
        }
    }
}
