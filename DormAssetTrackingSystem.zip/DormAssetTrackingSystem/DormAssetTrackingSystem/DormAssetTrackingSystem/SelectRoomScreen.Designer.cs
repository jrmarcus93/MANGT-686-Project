﻿
using Microsoft.VisualBasic;
using System;
using System.Collections;
using System.Collections.Generic;
using System.Data;
using System.Diagnostics;
namespace DormAssetTrackingSystem
{
    [Microsoft.VisualBasic.CompilerServices.DesignerGenerated()]
    partial class SelectRoomScreen : System.Windows.Forms.Form
    {

        //Form overrides dispose to clean up the component list.
        [System.Diagnostics.DebuggerNonUserCode()]
        protected override void Dispose(bool disposing)
        {
            try
            {
                if (disposing && components != null)
                {
                    components.Dispose();
                }
            }
            finally
            {
                base.Dispose(disposing);
            }
        }

        //Required by the Windows Form Designer

        private System.ComponentModel.IContainer components;
        //NOTE: The following procedure is required by the Windows Form Designer
        //It can be modified using the Windows Form Designer.  
        //Do not modify it using the code editor.
        [System.Diagnostics.DebuggerStepThrough()]
        private void InitializeComponent()
        {
            this.Label1 = new System.Windows.Forms.Label();
            this.dlHousingComplex = new System.Windows.Forms.ComboBox();
            this.Label2 = new System.Windows.Forms.Label();
            this.dlBuilding = new System.Windows.Forms.ComboBox();
            this.Label3 = new System.Windows.Forms.Label();
            this.llManageUsers = new System.Windows.Forms.LinkLabel();
            this.llPurchaseRequisition = new System.Windows.Forms.LinkLabel();
            this.llRunViewReports = new System.Windows.Forms.LinkLabel();
            this.llLogOut = new System.Windows.Forms.LinkLabel();
            this.llUpdateRoomInventory = new System.Windows.Forms.LinkLabel();
            this.llHome = new System.Windows.Forms.LinkLabel();
            this.Splitter1 = new System.Windows.Forms.Splitter();
            this.dlFloorNumber = new System.Windows.Forms.ComboBox();
            this.dlRoomNumber = new System.Windows.Forms.ComboBox();
            this.Label4 = new System.Windows.Forms.Label();
            this.bnUpdateInventory = new System.Windows.Forms.Button();
            this.llExit = new System.Windows.Forms.LinkLabel();
            this.SuspendLayout();
            // 
            // Label1
            // 
            this.Label1.AutoSize = true;
            this.Label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Label1.Location = new System.Drawing.Point(190, 30);
            this.Label1.Name = "Label1";
            this.Label1.Size = new System.Drawing.Size(164, 17);
            this.Label1.TabIndex = 4;
            this.Label1.Text = "Select Housing Complex:";
            // 
            // dlHousingComplex
            // 
            this.dlHousingComplex.FormattingEnabled = true;
            this.dlHousingComplex.Location = new System.Drawing.Point(176, 50);
            this.dlHousingComplex.Name = "dlHousingComplex";
            this.dlHousingComplex.Size = new System.Drawing.Size(200, 21);
            this.dlHousingComplex.TabIndex = 5;
            this.dlHousingComplex.SelectedIndexChanged += new System.EventHandler(this.dlHousingComplex_SelectedIndexChanged);
            // 
            // Label2
            // 
            this.Label2.AutoSize = true;
            this.Label2.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F);
            this.Label2.Location = new System.Drawing.Point(220, 83);
            this.Label2.Name = "Label2";
            this.Label2.Size = new System.Drawing.Size(105, 17);
            this.Label2.TabIndex = 6;
            this.Label2.Text = "Select Building:";
            // 
            // dlBuilding
            // 
            this.dlBuilding.FormattingEnabled = true;
            this.dlBuilding.Location = new System.Drawing.Point(176, 103);
            this.dlBuilding.Name = "dlBuilding";
            this.dlBuilding.Size = new System.Drawing.Size(200, 21);
            this.dlBuilding.TabIndex = 7;
            this.dlBuilding.SelectedIndexChanged += new System.EventHandler(this.dlBuilding_SelectedIndexChanged);
            // 
            // Label3
            // 
            this.Label3.AutoSize = true;
            this.Label3.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F);
            this.Label3.Location = new System.Drawing.Point(203, 139);
            this.Label3.Name = "Label3";
            this.Label3.Size = new System.Drawing.Size(141, 17);
            this.Label3.TabIndex = 8;
            this.Label3.Text = "Select Floor Number:";
            // 
            // llManageUsers
            // 
            this.llManageUsers.AutoSize = true;
            this.llManageUsers.BackColor = System.Drawing.Color.Indigo;
            this.llManageUsers.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F);
            this.llManageUsers.LinkColor = System.Drawing.Color.White;
            this.llManageUsers.Location = new System.Drawing.Point(1, 144);
            this.llManageUsers.Name = "llManageUsers";
            this.llManageUsers.Size = new System.Drawing.Size(100, 17);
            this.llManageUsers.TabIndex = 20;
            this.llManageUsers.TabStop = true;
            this.llManageUsers.Text = "Manage Users";
            this.llManageUsers.LinkClicked += new System.Windows.Forms.LinkLabelLinkClickedEventHandler(this.llManageUsers_LinkClicked);
            // 
            // llPurchaseRequisition
            // 
            this.llPurchaseRequisition.AutoSize = true;
            this.llPurchaseRequisition.BackColor = System.Drawing.Color.Indigo;
            this.llPurchaseRequisition.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F);
            this.llPurchaseRequisition.LinkColor = System.Drawing.Color.White;
            this.llPurchaseRequisition.Location = new System.Drawing.Point(2, 115);
            this.llPurchaseRequisition.Name = "llPurchaseRequisition";
            this.llPurchaseRequisition.Size = new System.Drawing.Size(142, 17);
            this.llPurchaseRequisition.TabIndex = 19;
            this.llPurchaseRequisition.TabStop = true;
            this.llPurchaseRequisition.Text = "Purchase Requisition";
            this.llPurchaseRequisition.LinkClicked += new System.Windows.Forms.LinkLabelLinkClickedEventHandler(this.llPurchaseRequisition_LinkClicked);
            // 
            // llRunViewReports
            // 
            this.llRunViewReports.AutoSize = true;
            this.llRunViewReports.BackColor = System.Drawing.Color.Indigo;
            this.llRunViewReports.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F);
            this.llRunViewReports.LinkColor = System.Drawing.Color.White;
            this.llRunViewReports.Location = new System.Drawing.Point(1, 85);
            this.llRunViewReports.Name = "llRunViewReports";
            this.llRunViewReports.Size = new System.Drawing.Size(121, 17);
            this.llRunViewReports.TabIndex = 18;
            this.llRunViewReports.TabStop = true;
            this.llRunViewReports.Text = "Run/View Reports";
            this.llRunViewReports.LinkClicked += new System.Windows.Forms.LinkLabelLinkClickedEventHandler(this.llRunViewReports_LinkClicked);
            // 
            // llLogOut
            // 
            this.llLogOut.AutoSize = true;
            this.llLogOut.BackColor = System.Drawing.Color.Indigo;
            this.llLogOut.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F);
            this.llLogOut.LinkColor = System.Drawing.Color.White;
            this.llLogOut.Location = new System.Drawing.Point(1, 271);
            this.llLogOut.Name = "llLogOut";
            this.llLogOut.Size = new System.Drawing.Size(59, 17);
            this.llLogOut.TabIndex = 17;
            this.llLogOut.TabStop = true;
            this.llLogOut.Text = "Log Out";
            this.llLogOut.LinkClicked += new System.Windows.Forms.LinkLabelLinkClickedEventHandler(this.llLogOut_LinkClicked);
            // 
            // llUpdateRoomInventory
            // 
            this.llUpdateRoomInventory.AutoSize = true;
            this.llUpdateRoomInventory.BackColor = System.Drawing.Color.Indigo;
            this.llUpdateRoomInventory.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F);
            this.llUpdateRoomInventory.LinkColor = System.Drawing.Color.Gray;
            this.llUpdateRoomInventory.Location = new System.Drawing.Point(1, 38);
            this.llUpdateRoomInventory.Name = "llUpdateRoomInventory";
            this.llUpdateRoomInventory.Size = new System.Drawing.Size(99, 34);
            this.llUpdateRoomInventory.TabIndex = 16;
            this.llUpdateRoomInventory.TabStop = true;
            this.llUpdateRoomInventory.Text = "Update Room \r\nInventory";
            // 
            // llHome
            // 
            this.llHome.AutoSize = true;
            this.llHome.BackColor = System.Drawing.Color.Indigo;
            this.llHome.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F);
            this.llHome.LinkColor = System.Drawing.Color.White;
            this.llHome.Location = new System.Drawing.Point(1, 9);
            this.llHome.Name = "llHome";
            this.llHome.Size = new System.Drawing.Size(45, 17);
            this.llHome.TabIndex = 15;
            this.llHome.TabStop = true;
            this.llHome.Text = "Home";
            this.llHome.LinkClicked += new System.Windows.Forms.LinkLabelLinkClickedEventHandler(this.llHome_LinkClicked);
            // 
            // Splitter1
            // 
            this.Splitter1.BackColor = System.Drawing.Color.Indigo;
            this.Splitter1.Location = new System.Drawing.Point(0, 0);
            this.Splitter1.Name = "Splitter1";
            this.Splitter1.Size = new System.Drawing.Size(151, 314);
            this.Splitter1.TabIndex = 14;
            this.Splitter1.TabStop = false;
            // 
            // dlFloorNumber
            // 
            this.dlFloorNumber.FormattingEnabled = true;
            this.dlFloorNumber.Location = new System.Drawing.Point(176, 162);
            this.dlFloorNumber.Name = "dlFloorNumber";
            this.dlFloorNumber.Size = new System.Drawing.Size(200, 21);
            this.dlFloorNumber.TabIndex = 21;
            this.dlFloorNumber.SelectedIndexChanged += new System.EventHandler(this.dlFloorNumber_SelectedIndexChanged);
            // 
            // dlRoomNumber
            // 
            this.dlRoomNumber.FormattingEnabled = true;
            this.dlRoomNumber.Location = new System.Drawing.Point(176, 219);
            this.dlRoomNumber.Name = "dlRoomNumber";
            this.dlRoomNumber.Size = new System.Drawing.Size(200, 21);
            this.dlRoomNumber.TabIndex = 23;
            // 
            // Label4
            // 
            this.Label4.AutoSize = true;
            this.Label4.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F);
            this.Label4.Location = new System.Drawing.Point(203, 196);
            this.Label4.Name = "Label4";
            this.Label4.Size = new System.Drawing.Size(146, 17);
            this.Label4.TabIndex = 22;
            this.Label4.Text = "Select Room Number:";
            // 
            // bnUpdateInventory
            // 
            this.bnUpdateInventory.BackColor = System.Drawing.SystemColors.ControlLight;
            this.bnUpdateInventory.Location = new System.Drawing.Point(226, 255);
            this.bnUpdateInventory.Name = "bnUpdateInventory";
            this.bnUpdateInventory.Size = new System.Drawing.Size(106, 23);
            this.bnUpdateInventory.TabIndex = 24;
            this.bnUpdateInventory.Text = "Update Inventory";
            this.bnUpdateInventory.UseVisualStyleBackColor = false;
            this.bnUpdateInventory.Click += new System.EventHandler(this.bnUpdateInventory_Click);
            // 
            // llExit
            // 
            this.llExit.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.llExit.AutoSize = true;
            this.llExit.BackColor = System.Drawing.Color.Indigo;
            this.llExit.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F);
            this.llExit.LinkColor = System.Drawing.Color.White;
            this.llExit.Location = new System.Drawing.Point(1, 288);
            this.llExit.Name = "llExit";
            this.llExit.Size = new System.Drawing.Size(30, 17);
            this.llExit.TabIndex = 25;
            this.llExit.TabStop = true;
            this.llExit.Text = "Exit";
            this.llExit.LinkClicked += new System.Windows.Forms.LinkLabelLinkClickedEventHandler(this.llExit_LinkClicked);
            // 
            // SelectRoomScreen
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.SystemColors.ControlDark;
            this.ClientSize = new System.Drawing.Size(406, 314);
            this.Controls.Add(this.llExit);
            this.Controls.Add(this.bnUpdateInventory);
            this.Controls.Add(this.dlRoomNumber);
            this.Controls.Add(this.Label4);
            this.Controls.Add(this.dlFloorNumber);
            this.Controls.Add(this.llManageUsers);
            this.Controls.Add(this.llPurchaseRequisition);
            this.Controls.Add(this.llRunViewReports);
            this.Controls.Add(this.llLogOut);
            this.Controls.Add(this.llUpdateRoomInventory);
            this.Controls.Add(this.llHome);
            this.Controls.Add(this.Splitter1);
            this.Controls.Add(this.Label3);
            this.Controls.Add(this.dlBuilding);
            this.Controls.Add(this.Label2);
            this.Controls.Add(this.dlHousingComplex);
            this.Controls.Add(this.Label1);
            this.Name = "SelectRoomScreen";
            this.Text = "Update Room Inventory";
            this.ResumeLayout(false);
            this.PerformLayout();

        }
        internal System.Windows.Forms.Label Label1;
        internal System.Windows.Forms.ComboBox dlHousingComplex;
        internal System.Windows.Forms.Label Label2;
        internal System.Windows.Forms.ComboBox dlBuilding;
        internal System.Windows.Forms.Label Label3;
        internal System.Windows.Forms.LinkLabel llManageUsers;
        internal System.Windows.Forms.LinkLabel llPurchaseRequisition;
        internal System.Windows.Forms.LinkLabel llRunViewReports;
        internal System.Windows.Forms.LinkLabel llLogOut;
        internal System.Windows.Forms.LinkLabel llUpdateRoomInventory;
        internal System.Windows.Forms.LinkLabel llHome;
        internal System.Windows.Forms.Splitter Splitter1;
        internal System.Windows.Forms.ComboBox dlFloorNumber;
        internal System.Windows.Forms.ComboBox dlRoomNumber;
        internal System.Windows.Forms.Label Label4;
        internal System.Windows.Forms.Button bnUpdateInventory;
        internal System.Windows.Forms.LinkLabel llExit;
    }
}