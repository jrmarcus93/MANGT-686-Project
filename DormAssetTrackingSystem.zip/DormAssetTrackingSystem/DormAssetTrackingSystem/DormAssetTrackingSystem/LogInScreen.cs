﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Xml;
using IBM.Data.DB2;

namespace DormAssetTrackingSystem
{
    public partial class LogInScreen : Form
    {
        private string username;
        private string password;
        private string queryPassword;

        public LogInScreen()
        {
            InitializeComponent();
            //Insert PctureBox image
            //PictureBox1.Image = 
        }

        private void bnCancel_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

        private void bnSubmit_Click(object sender, EventArgs e)
        {
            //create database connection
            DB2Connection conn = new DB2Connection();
            conn.ConnectionString = "Server=nimitz.cba.ksu.edu:50000;Database=Group1;UID=group1;PWD=Grp1313;";
            conn.Open();

            //get user input
            username = tbUsername.Text.ToLower();
            password = tbPassword.Text;

            //set up database query
            string queryString = "SELECT PASSWORD, FIRST_NAME FROM USER WHERE USERNAME = '" + username + "'";
            DB2Command cmdQuery = new DB2Command(queryString, conn);
            DB2DataReader reader = cmdQuery.ExecuteReader();

            //get password info from database
            if (reader.HasRows)
            {
                while (reader.Read())
                {
                    queryPassword = reader.GetString(0);

                    //if passwords match, allow login
                    if (queryPassword.Equals(password))
                    {
                        //start application ***Is there a better way to do this?***
                        HomeScreen home = new HomeScreen(reader.GetString(1));
                        this.Hide();
                        home.Closed += (s, args) => this.Close();
                        home.Show();
                    }
                    else
                    {
                        MessageBox.Show("Invalid password.\nPlease try again.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    }
                }
            }
            else
            {
                MessageBox.Show("Invalid username.\nPlease try again.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            reader.Close();
            conn.Close();
        }
    }
}
