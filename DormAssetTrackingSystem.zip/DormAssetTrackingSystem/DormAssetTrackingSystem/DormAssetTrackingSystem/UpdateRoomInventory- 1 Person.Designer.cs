﻿
using Microsoft.VisualBasic;
using System;
using System.Collections;
using System.Collections.Generic;
using System.Data;
using System.Diagnostics;
namespace DormAssetTrackingSystem
{
    [Microsoft.VisualBasic.CompilerServices.DesignerGenerated()]
    partial class UpdateRoomInventory__1_Person : System.Windows.Forms.Form
    {

        //Form overrides dispose to clean up the component list.
        [System.Diagnostics.DebuggerNonUserCode()]
        protected override void Dispose(bool disposing)
        {
            try
            {
                if (disposing && components != null)
                {
                    components.Dispose();
                }
            }
            finally
            {
                base.Dispose(disposing);
            }
        }

        //Required by the Windows Form Designer

        private System.ComponentModel.IContainer components;
        //NOTE: The following procedure is required by the Windows Form Designer
        //It can be modified using the Windows Form Designer.  
        //Do not modify it using the code editor.
        [System.Diagnostics.DebuggerStepThrough()]
        private void InitializeComponent()
        {
            this.ManageUserLinkLabel = new System.Windows.Forms.LinkLabel();
            this.PurchaseReqLinkLabel = new System.Windows.Forms.LinkLabel();
            this.ReportsLinkLabel = new System.Windows.Forms.LinkLabel();
            this.LogOutLinkLabel = new System.Windows.Forms.LinkLabel();
            this.UpdateRoomLinkLabel = new System.Windows.Forms.LinkLabel();
            this.HomeLinkLabel = new System.Windows.Forms.LinkLabel();
            this.Splitter1 = new System.Windows.Forms.Splitter();
            this.ExitLinkLabel = new System.Windows.Forms.LinkLabel();
            this.Label1 = new System.Windows.Forms.Label();
            this.Label2 = new System.Windows.Forms.Label();
            this.tbMattressIDNumber = new System.Windows.Forms.TextBox();
            this.cbMattressPresent = new System.Windows.Forms.CheckBox();
            this.Label3 = new System.Windows.Forms.Label();
            this.Label4 = new System.Windows.Forms.Label();
            this.cbMattressReplace = new System.Windows.Forms.CheckBox();
            this.tbMattressComments = new System.Windows.Forms.TextBox();
            this.Label5 = new System.Windows.Forms.Label();
            this.Label6 = new System.Windows.Forms.Label();
            this.Label7 = new System.Windows.Forms.Label();
            this.tbBedFrameComments = new System.Windows.Forms.TextBox();
            this.Label8 = new System.Windows.Forms.Label();
            this.cbBedFrameReplace = new System.Windows.Forms.CheckBox();
            this.Label9 = new System.Windows.Forms.Label();
            this.cbBedFramePresent = new System.Windows.Forms.CheckBox();
            this.tbBedFrameIDNumber = new System.Windows.Forms.TextBox();
            this.Label10 = new System.Windows.Forms.Label();
            this.Label11 = new System.Windows.Forms.Label();
            this.Label12 = new System.Windows.Forms.Label();
            this.tbDeskComments = new System.Windows.Forms.TextBox();
            this.Label13 = new System.Windows.Forms.Label();
            this.cbDeskReplace = new System.Windows.Forms.CheckBox();
            this.Label14 = new System.Windows.Forms.Label();
            this.cbDeskPresent = new System.Windows.Forms.CheckBox();
            this.tbDeskIDNumber = new System.Windows.Forms.TextBox();
            this.Label15 = new System.Windows.Forms.Label();
            this.Label16 = new System.Windows.Forms.Label();
            this.Label17 = new System.Windows.Forms.Label();
            this.tbDressersComments = new System.Windows.Forms.TextBox();
            this.Label18 = new System.Windows.Forms.Label();
            this.cbDressersReplace = new System.Windows.Forms.CheckBox();
            this.Label19 = new System.Windows.Forms.Label();
            this.cbDressersPresent = new System.Windows.Forms.CheckBox();
            this.tbDressersIdNumber = new System.Windows.Forms.TextBox();
            this.Label20 = new System.Windows.Forms.Label();
            this.Label21 = new System.Windows.Forms.Label();
            this.dlChairsQuantity = new System.Windows.Forms.ComboBox();
            this.Label22 = new System.Windows.Forms.Label();
            this.dlTrashCanQuantity = new System.Windows.Forms.ComboBox();
            this.Label23 = new System.Windows.Forms.Label();
            this.Label24 = new System.Windows.Forms.Label();
            this.tbRoomComments = new System.Windows.Forms.TextBox();
            this.bnSubmit = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // ManageUserLinkLabel
            // 
            this.ManageUserLinkLabel.AutoSize = true;
            this.ManageUserLinkLabel.BackColor = System.Drawing.Color.Indigo;
            this.ManageUserLinkLabel.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F);
            this.ManageUserLinkLabel.LinkColor = System.Drawing.Color.White;
            this.ManageUserLinkLabel.Location = new System.Drawing.Point(4, 144);
            this.ManageUserLinkLabel.Name = "ManageUserLinkLabel";
            this.ManageUserLinkLabel.Size = new System.Drawing.Size(100, 17);
            this.ManageUserLinkLabel.TabIndex = 27;
            this.ManageUserLinkLabel.TabStop = true;
            this.ManageUserLinkLabel.Text = "Manage Users";
            // 
            // PurchaseReqLinkLabel
            // 
            this.PurchaseReqLinkLabel.AutoSize = true;
            this.PurchaseReqLinkLabel.BackColor = System.Drawing.Color.Indigo;
            this.PurchaseReqLinkLabel.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F);
            this.PurchaseReqLinkLabel.LinkColor = System.Drawing.Color.White;
            this.PurchaseReqLinkLabel.Location = new System.Drawing.Point(5, 114);
            this.PurchaseReqLinkLabel.Name = "PurchaseReqLinkLabel";
            this.PurchaseReqLinkLabel.Size = new System.Drawing.Size(142, 17);
            this.PurchaseReqLinkLabel.TabIndex = 26;
            this.PurchaseReqLinkLabel.TabStop = true;
            this.PurchaseReqLinkLabel.Text = "Purchase Requisition";
            // 
            // ReportsLinkLabel
            // 
            this.ReportsLinkLabel.AutoSize = true;
            this.ReportsLinkLabel.BackColor = System.Drawing.Color.Indigo;
            this.ReportsLinkLabel.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F);
            this.ReportsLinkLabel.LinkColor = System.Drawing.Color.White;
            this.ReportsLinkLabel.Location = new System.Drawing.Point(4, 84);
            this.ReportsLinkLabel.Name = "ReportsLinkLabel";
            this.ReportsLinkLabel.Size = new System.Drawing.Size(121, 17);
            this.ReportsLinkLabel.TabIndex = 25;
            this.ReportsLinkLabel.TabStop = true;
            this.ReportsLinkLabel.Text = "Run/View Reports";
            // 
            // LogOutLinkLabel
            // 
            this.LogOutLinkLabel.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.LogOutLinkLabel.AutoSize = true;
            this.LogOutLinkLabel.BackColor = System.Drawing.Color.Indigo;
            this.LogOutLinkLabel.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F);
            this.LogOutLinkLabel.LinkColor = System.Drawing.Color.White;
            this.LogOutLinkLabel.Location = new System.Drawing.Point(5, 374);
            this.LogOutLinkLabel.Name = "LogOutLinkLabel";
            this.LogOutLinkLabel.Size = new System.Drawing.Size(59, 17);
            this.LogOutLinkLabel.TabIndex = 24;
            this.LogOutLinkLabel.TabStop = true;
            this.LogOutLinkLabel.Text = "Log Out";
            // 
            // UpdateRoomLinkLabel
            // 
            this.UpdateRoomLinkLabel.AutoSize = true;
            this.UpdateRoomLinkLabel.BackColor = System.Drawing.Color.Indigo;
            this.UpdateRoomLinkLabel.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F);
            this.UpdateRoomLinkLabel.LinkColor = System.Drawing.Color.White;
            this.UpdateRoomLinkLabel.Location = new System.Drawing.Point(5, 38);
            this.UpdateRoomLinkLabel.Name = "UpdateRoomLinkLabel";
            this.UpdateRoomLinkLabel.Size = new System.Drawing.Size(99, 34);
            this.UpdateRoomLinkLabel.TabIndex = 23;
            this.UpdateRoomLinkLabel.TabStop = true;
            this.UpdateRoomLinkLabel.Text = "Update Room \r\nInventory";
            // 
            // HomeLinkLabel
            // 
            this.HomeLinkLabel.AutoSize = true;
            this.HomeLinkLabel.BackColor = System.Drawing.Color.Indigo;
            this.HomeLinkLabel.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F);
            this.HomeLinkLabel.LinkColor = System.Drawing.Color.White;
            this.HomeLinkLabel.Location = new System.Drawing.Point(5, 9);
            this.HomeLinkLabel.Name = "HomeLinkLabel";
            this.HomeLinkLabel.Size = new System.Drawing.Size(45, 17);
            this.HomeLinkLabel.TabIndex = 22;
            this.HomeLinkLabel.TabStop = true;
            this.HomeLinkLabel.Text = "Home";
            // 
            // Splitter1
            // 
            this.Splitter1.BackColor = System.Drawing.Color.Indigo;
            this.Splitter1.Location = new System.Drawing.Point(0, 0);
            this.Splitter1.Name = "Splitter1";
            this.Splitter1.Size = new System.Drawing.Size(156, 426);
            this.Splitter1.TabIndex = 21;
            this.Splitter1.TabStop = false;
            // 
            // ExitLinkLabel
            // 
            this.ExitLinkLabel.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.ExitLinkLabel.AutoSize = true;
            this.ExitLinkLabel.BackColor = System.Drawing.Color.Indigo;
            this.ExitLinkLabel.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F);
            this.ExitLinkLabel.LinkColor = System.Drawing.Color.White;
            this.ExitLinkLabel.Location = new System.Drawing.Point(5, 400);
            this.ExitLinkLabel.Name = "ExitLinkLabel";
            this.ExitLinkLabel.Size = new System.Drawing.Size(30, 17);
            this.ExitLinkLabel.TabIndex = 28;
            this.ExitLinkLabel.TabStop = true;
            this.ExitLinkLabel.Text = "Exit";
            // 
            // Label1
            // 
            this.Label1.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.Label1.AutoSize = true;
            this.Label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Underline))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Label1.Location = new System.Drawing.Point(327, 16);
            this.Label1.Name = "Label1";
            this.Label1.Size = new System.Drawing.Size(87, 24);
            this.Label1.TabIndex = 29;
            this.Label1.Text = "Mattress";
            // 
            // Label2
            // 
            this.Label2.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.Label2.AutoSize = true;
            this.Label2.Location = new System.Drawing.Point(207, 44);
            this.Label2.Name = "Label2";
            this.Label2.Size = new System.Drawing.Size(58, 13);
            this.Label2.TabIndex = 30;
            this.Label2.Text = "ID Number";
            // 
            // tbMattressIDNumber
            // 
            this.tbMattressIDNumber.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.tbMattressIDNumber.Location = new System.Drawing.Point(173, 58);
            this.tbMattressIDNumber.Name = "tbMattressIDNumber";
            this.tbMattressIDNumber.Size = new System.Drawing.Size(127, 20);
            this.tbMattressIDNumber.TabIndex = 31;
            // 
            // cbMattressPresent
            // 
            this.cbMattressPresent.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.cbMattressPresent.Location = new System.Drawing.Point(343, 61);
            this.cbMattressPresent.Name = "cbMattressPresent";
            this.cbMattressPresent.Size = new System.Drawing.Size(15, 14);
            this.cbMattressPresent.TabIndex = 32;
            this.cbMattressPresent.UseVisualStyleBackColor = true;
            // 
            // Label3
            // 
            this.Label3.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.Label3.AutoSize = true;
            this.Label3.Location = new System.Drawing.Point(331, 44);
            this.Label3.Name = "Label3";
            this.Label3.Size = new System.Drawing.Size(49, 13);
            this.Label3.TabIndex = 33;
            this.Label3.Text = "Present?";
            // 
            // Label4
            // 
            this.Label4.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.Label4.AutoSize = true;
            this.Label4.Location = new System.Drawing.Point(385, 44);
            this.Label4.Name = "Label4";
            this.Label4.Size = new System.Drawing.Size(53, 13);
            this.Label4.TabIndex = 35;
            this.Label4.Text = "Replace?";
            // 
            // cbMattressReplace
            // 
            this.cbMattressReplace.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.cbMattressReplace.Location = new System.Drawing.Point(401, 60);
            this.cbMattressReplace.Name = "cbMattressReplace";
            this.cbMattressReplace.Size = new System.Drawing.Size(16, 17);
            this.cbMattressReplace.TabIndex = 34;
            this.cbMattressReplace.UseVisualStyleBackColor = true;
            // 
            // tbMattressComments
            // 
            this.tbMattressComments.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.tbMattressComments.Location = new System.Drawing.Point(459, 56);
            this.tbMattressComments.Name = "tbMattressComments";
            this.tbMattressComments.Size = new System.Drawing.Size(177, 20);
            this.tbMattressComments.TabIndex = 36;
            // 
            // Label5
            // 
            this.Label5.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.Label5.AutoSize = true;
            this.Label5.Location = new System.Drawing.Point(515, 43);
            this.Label5.Name = "Label5";
            this.Label5.Size = new System.Drawing.Size(56, 13);
            this.Label5.TabIndex = 37;
            this.Label5.Text = "Comments";
            // 
            // Label6
            // 
            this.Label6.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.Label6.AutoSize = true;
            this.Label6.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Underline))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Label6.Location = new System.Drawing.Point(319, 82);
            this.Label6.Name = "Label6";
            this.Label6.Size = new System.Drawing.Size(113, 24);
            this.Label6.TabIndex = 38;
            this.Label6.Text = "Bed Frame";
            // 
            // Label7
            // 
            this.Label7.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.Label7.AutoSize = true;
            this.Label7.Location = new System.Drawing.Point(515, 110);
            this.Label7.Name = "Label7";
            this.Label7.Size = new System.Drawing.Size(56, 13);
            this.Label7.TabIndex = 46;
            this.Label7.Text = "Comments";
            // 
            // tbBedFrameComments
            // 
            this.tbBedFrameComments.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.tbBedFrameComments.Location = new System.Drawing.Point(459, 123);
            this.tbBedFrameComments.Name = "tbBedFrameComments";
            this.tbBedFrameComments.Size = new System.Drawing.Size(177, 20);
            this.tbBedFrameComments.TabIndex = 45;
            // 
            // Label8
            // 
            this.Label8.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.Label8.AutoSize = true;
            this.Label8.Location = new System.Drawing.Point(385, 111);
            this.Label8.Name = "Label8";
            this.Label8.Size = new System.Drawing.Size(53, 13);
            this.Label8.TabIndex = 44;
            this.Label8.Text = "Replace?";
            // 
            // cbBedFrameReplace
            // 
            this.cbBedFrameReplace.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.cbBedFrameReplace.Location = new System.Drawing.Point(401, 127);
            this.cbBedFrameReplace.Name = "cbBedFrameReplace";
            this.cbBedFrameReplace.Size = new System.Drawing.Size(16, 17);
            this.cbBedFrameReplace.TabIndex = 43;
            this.cbBedFrameReplace.UseVisualStyleBackColor = true;
            // 
            // Label9
            // 
            this.Label9.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.Label9.AutoSize = true;
            this.Label9.Location = new System.Drawing.Point(331, 111);
            this.Label9.Name = "Label9";
            this.Label9.Size = new System.Drawing.Size(49, 13);
            this.Label9.TabIndex = 42;
            this.Label9.Text = "Present?";
            // 
            // cbBedFramePresent
            // 
            this.cbBedFramePresent.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.cbBedFramePresent.Location = new System.Drawing.Point(343, 128);
            this.cbBedFramePresent.Name = "cbBedFramePresent";
            this.cbBedFramePresent.Size = new System.Drawing.Size(15, 14);
            this.cbBedFramePresent.TabIndex = 41;
            this.cbBedFramePresent.UseVisualStyleBackColor = true;
            // 
            // tbBedFrameIDNumber
            // 
            this.tbBedFrameIDNumber.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.tbBedFrameIDNumber.Location = new System.Drawing.Point(173, 125);
            this.tbBedFrameIDNumber.Name = "tbBedFrameIDNumber";
            this.tbBedFrameIDNumber.Size = new System.Drawing.Size(127, 20);
            this.tbBedFrameIDNumber.TabIndex = 40;
            // 
            // Label10
            // 
            this.Label10.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.Label10.AutoSize = true;
            this.Label10.Location = new System.Drawing.Point(207, 111);
            this.Label10.Name = "Label10";
            this.Label10.Size = new System.Drawing.Size(58, 13);
            this.Label10.TabIndex = 39;
            this.Label10.Text = "ID Number";
            // 
            // Label11
            // 
            this.Label11.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.Label11.AutoSize = true;
            this.Label11.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Label11.Location = new System.Drawing.Point(169, 311);
            this.Label11.Name = "Label11";
            this.Label11.Size = new System.Drawing.Size(68, 20);
            this.Label11.TabIndex = 47;
            this.Label11.Text = "Chair(s):";
            // 
            // Label12
            // 
            this.Label12.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.Label12.AutoSize = true;
            this.Label12.Location = new System.Drawing.Point(515, 173);
            this.Label12.Name = "Label12";
            this.Label12.Size = new System.Drawing.Size(56, 13);
            this.Label12.TabIndex = 56;
            this.Label12.Text = "Comments";
            // 
            // tbDeskComments
            // 
            this.tbDeskComments.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.tbDeskComments.Location = new System.Drawing.Point(459, 186);
            this.tbDeskComments.Name = "tbDeskComments";
            this.tbDeskComments.Size = new System.Drawing.Size(177, 20);
            this.tbDeskComments.TabIndex = 55;
            // 
            // Label13
            // 
            this.Label13.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.Label13.AutoSize = true;
            this.Label13.Location = new System.Drawing.Point(385, 174);
            this.Label13.Name = "Label13";
            this.Label13.Size = new System.Drawing.Size(53, 13);
            this.Label13.TabIndex = 54;
            this.Label13.Text = "Replace?";
            // 
            // cbDeskReplace
            // 
            this.cbDeskReplace.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.cbDeskReplace.Location = new System.Drawing.Point(401, 190);
            this.cbDeskReplace.Name = "cbDeskReplace";
            this.cbDeskReplace.Size = new System.Drawing.Size(16, 17);
            this.cbDeskReplace.TabIndex = 53;
            this.cbDeskReplace.UseVisualStyleBackColor = true;
            // 
            // Label14
            // 
            this.Label14.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.Label14.AutoSize = true;
            this.Label14.Location = new System.Drawing.Point(331, 174);
            this.Label14.Name = "Label14";
            this.Label14.Size = new System.Drawing.Size(49, 13);
            this.Label14.TabIndex = 52;
            this.Label14.Text = "Present?";
            // 
            // cbDeskPresent
            // 
            this.cbDeskPresent.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.cbDeskPresent.Location = new System.Drawing.Point(343, 191);
            this.cbDeskPresent.Name = "cbDeskPresent";
            this.cbDeskPresent.Size = new System.Drawing.Size(15, 14);
            this.cbDeskPresent.TabIndex = 51;
            this.cbDeskPresent.UseVisualStyleBackColor = true;
            // 
            // tbDeskIDNumber
            // 
            this.tbDeskIDNumber.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.tbDeskIDNumber.Location = new System.Drawing.Point(173, 188);
            this.tbDeskIDNumber.Name = "tbDeskIDNumber";
            this.tbDeskIDNumber.Size = new System.Drawing.Size(127, 20);
            this.tbDeskIDNumber.TabIndex = 50;
            // 
            // Label15
            // 
            this.Label15.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.Label15.AutoSize = true;
            this.Label15.Location = new System.Drawing.Point(207, 174);
            this.Label15.Name = "Label15";
            this.Label15.Size = new System.Drawing.Size(58, 13);
            this.Label15.TabIndex = 49;
            this.Label15.Text = "ID Number";
            // 
            // Label16
            // 
            this.Label16.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.Label16.AutoSize = true;
            this.Label16.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Underline))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Label16.Location = new System.Drawing.Point(337, 147);
            this.Label16.Name = "Label16";
            this.Label16.Size = new System.Drawing.Size(66, 24);
            this.Label16.TabIndex = 48;
            this.Label16.Text = "Desks";
            // 
            // Label17
            // 
            this.Label17.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.Label17.AutoSize = true;
            this.Label17.Location = new System.Drawing.Point(515, 235);
            this.Label17.Name = "Label17";
            this.Label17.Size = new System.Drawing.Size(56, 13);
            this.Label17.TabIndex = 65;
            this.Label17.Text = "Comments";
            // 
            // tbDressersComments
            // 
            this.tbDressersComments.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.tbDressersComments.Location = new System.Drawing.Point(459, 248);
            this.tbDressersComments.Name = "tbDressersComments";
            this.tbDressersComments.Size = new System.Drawing.Size(177, 20);
            this.tbDressersComments.TabIndex = 64;
            // 
            // Label18
            // 
            this.Label18.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.Label18.AutoSize = true;
            this.Label18.Location = new System.Drawing.Point(385, 236);
            this.Label18.Name = "Label18";
            this.Label18.Size = new System.Drawing.Size(53, 13);
            this.Label18.TabIndex = 63;
            this.Label18.Text = "Replace?";
            // 
            // cbDressersReplace
            // 
            this.cbDressersReplace.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.cbDressersReplace.Location = new System.Drawing.Point(401, 252);
            this.cbDressersReplace.Name = "cbDressersReplace";
            this.cbDressersReplace.Size = new System.Drawing.Size(16, 17);
            this.cbDressersReplace.TabIndex = 62;
            this.cbDressersReplace.UseVisualStyleBackColor = true;
            // 
            // Label19
            // 
            this.Label19.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.Label19.AutoSize = true;
            this.Label19.Location = new System.Drawing.Point(331, 236);
            this.Label19.Name = "Label19";
            this.Label19.Size = new System.Drawing.Size(49, 13);
            this.Label19.TabIndex = 61;
            this.Label19.Text = "Present?";
            // 
            // cbDressersPresent
            // 
            this.cbDressersPresent.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.cbDressersPresent.Location = new System.Drawing.Point(343, 253);
            this.cbDressersPresent.Name = "cbDressersPresent";
            this.cbDressersPresent.Size = new System.Drawing.Size(15, 14);
            this.cbDressersPresent.TabIndex = 60;
            this.cbDressersPresent.UseVisualStyleBackColor = true;
            // 
            // tbDressersIdNumber
            // 
            this.tbDressersIdNumber.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.tbDressersIdNumber.Location = new System.Drawing.Point(173, 250);
            this.tbDressersIdNumber.Name = "tbDressersIdNumber";
            this.tbDressersIdNumber.Size = new System.Drawing.Size(127, 20);
            this.tbDressersIdNumber.TabIndex = 59;
            // 
            // Label20
            // 
            this.Label20.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.Label20.AutoSize = true;
            this.Label20.Location = new System.Drawing.Point(207, 236);
            this.Label20.Name = "Label20";
            this.Label20.Size = new System.Drawing.Size(58, 13);
            this.Label20.TabIndex = 58;
            this.Label20.Text = "ID Number";
            // 
            // Label21
            // 
            this.Label21.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.Label21.AutoSize = true;
            this.Label21.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Underline))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Label21.Location = new System.Drawing.Point(324, 210);
            this.Label21.Name = "Label21";
            this.Label21.Size = new System.Drawing.Size(92, 24);
            this.Label21.TabIndex = 57;
            this.Label21.Text = "Dressers";
            // 
            // dlChairsQuantity
            // 
            this.dlChairsQuantity.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.dlChairsQuantity.FormattingEnabled = true;
            this.dlChairsQuantity.Items.AddRange(new object[] {
            "1",
            "2",
            "3",
            "4",
            "5",
            "6"});
            this.dlChairsQuantity.Location = new System.Drawing.Point(267, 313);
            this.dlChairsQuantity.Name = "dlChairsQuantity";
            this.dlChairsQuantity.Size = new System.Drawing.Size(46, 21);
            this.dlChairsQuantity.TabIndex = 66;
            // 
            // Label22
            // 
            this.Label22.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.Label22.AutoSize = true;
            this.Label22.Location = new System.Drawing.Point(257, 294);
            this.Label22.Name = "Label22";
            this.Label22.Size = new System.Drawing.Size(71, 13);
            this.Label22.TabIndex = 67;
            this.Label22.Text = "Qty. Present?";
            // 
            // dlTrashCanQuantity
            // 
            this.dlTrashCanQuantity.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.dlTrashCanQuantity.FormattingEnabled = true;
            this.dlTrashCanQuantity.Items.AddRange(new object[] {
            "1",
            "2",
            "3",
            "4",
            "5",
            "6"});
            this.dlTrashCanQuantity.Location = new System.Drawing.Point(267, 347);
            this.dlTrashCanQuantity.Name = "dlTrashCanQuantity";
            this.dlTrashCanQuantity.Size = new System.Drawing.Size(46, 21);
            this.dlTrashCanQuantity.TabIndex = 69;
            // 
            // Label23
            // 
            this.Label23.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.Label23.AutoSize = true;
            this.Label23.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Label23.Location = new System.Drawing.Point(169, 345);
            this.Label23.Name = "Label23";
            this.Label23.Size = new System.Drawing.Size(94, 20);
            this.Label23.TabIndex = 68;
            this.Label23.Text = "Trash Cans:";
            // 
            // Label24
            // 
            this.Label24.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.Label24.AutoSize = true;
            this.Label24.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Label24.Location = new System.Drawing.Point(339, 311);
            this.Label24.Name = "Label24";
            this.Label24.Size = new System.Drawing.Size(90, 40);
            this.Label24.TabIndex = 70;
            this.Label24.Text = "Room \r\nComments:";
            // 
            // tbRoomComments
            // 
            this.tbRoomComments.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.tbRoomComments.Location = new System.Drawing.Point(435, 311);
            this.tbRoomComments.Multiline = true;
            this.tbRoomComments.Name = "tbRoomComments";
            this.tbRoomComments.Size = new System.Drawing.Size(200, 73);
            this.tbRoomComments.TabIndex = 71;
            // 
            // bnSubmit
            // 
            this.bnSubmit.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.bnSubmit.BackColor = System.Drawing.SystemColors.Control;
            this.bnSubmit.Location = new System.Drawing.Point(323, 391);
            this.bnSubmit.Name = "bnSubmit";
            this.bnSubmit.Size = new System.Drawing.Size(75, 23);
            this.bnSubmit.TabIndex = 72;
            this.bnSubmit.Text = "Submit";
            this.bnSubmit.UseVisualStyleBackColor = false;
            // 
            // UpdateRoomInventory__1_Person
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.SystemColors.ControlDark;
            this.ClientSize = new System.Drawing.Size(657, 426);
            this.Controls.Add(this.bnSubmit);
            this.Controls.Add(this.tbRoomComments);
            this.Controls.Add(this.Label24);
            this.Controls.Add(this.dlTrashCanQuantity);
            this.Controls.Add(this.Label23);
            this.Controls.Add(this.Label22);
            this.Controls.Add(this.dlChairsQuantity);
            this.Controls.Add(this.Label17);
            this.Controls.Add(this.tbDressersComments);
            this.Controls.Add(this.Label18);
            this.Controls.Add(this.cbDressersReplace);
            this.Controls.Add(this.Label19);
            this.Controls.Add(this.cbDressersPresent);
            this.Controls.Add(this.tbDressersIdNumber);
            this.Controls.Add(this.Label20);
            this.Controls.Add(this.Label21);
            this.Controls.Add(this.Label12);
            this.Controls.Add(this.tbDeskComments);
            this.Controls.Add(this.Label13);
            this.Controls.Add(this.cbDeskReplace);
            this.Controls.Add(this.Label14);
            this.Controls.Add(this.cbDeskPresent);
            this.Controls.Add(this.tbDeskIDNumber);
            this.Controls.Add(this.Label15);
            this.Controls.Add(this.Label16);
            this.Controls.Add(this.Label11);
            this.Controls.Add(this.Label7);
            this.Controls.Add(this.tbBedFrameComments);
            this.Controls.Add(this.Label8);
            this.Controls.Add(this.cbBedFrameReplace);
            this.Controls.Add(this.Label9);
            this.Controls.Add(this.cbBedFramePresent);
            this.Controls.Add(this.tbBedFrameIDNumber);
            this.Controls.Add(this.Label10);
            this.Controls.Add(this.Label6);
            this.Controls.Add(this.Label5);
            this.Controls.Add(this.tbMattressComments);
            this.Controls.Add(this.Label4);
            this.Controls.Add(this.cbMattressReplace);
            this.Controls.Add(this.Label3);
            this.Controls.Add(this.cbMattressPresent);
            this.Controls.Add(this.tbMattressIDNumber);
            this.Controls.Add(this.Label2);
            this.Controls.Add(this.Label1);
            this.Controls.Add(this.ExitLinkLabel);
            this.Controls.Add(this.ManageUserLinkLabel);
            this.Controls.Add(this.PurchaseReqLinkLabel);
            this.Controls.Add(this.ReportsLinkLabel);
            this.Controls.Add(this.LogOutLinkLabel);
            this.Controls.Add(this.UpdateRoomLinkLabel);
            this.Controls.Add(this.HomeLinkLabel);
            this.Controls.Add(this.Splitter1);
            this.MaximizeBox = false;
            this.MaximumSize = new System.Drawing.Size(673, 464);
            this.MinimumSize = new System.Drawing.Size(673, 464);
            this.Name = "UpdateRoomInventory__1_Person";
            this.Text = "Update Room Inventory- 1 Person";
            this.ResumeLayout(false);
            this.PerformLayout();

        }
        internal System.Windows.Forms.LinkLabel ManageUserLinkLabel;
        internal System.Windows.Forms.LinkLabel PurchaseReqLinkLabel;
        internal System.Windows.Forms.LinkLabel ReportsLinkLabel;
        internal System.Windows.Forms.LinkLabel LogOutLinkLabel;
        internal System.Windows.Forms.LinkLabel UpdateRoomLinkLabel;
        internal System.Windows.Forms.LinkLabel HomeLinkLabel;
        internal System.Windows.Forms.Splitter Splitter1;
        internal System.Windows.Forms.LinkLabel ExitLinkLabel;
        internal System.Windows.Forms.Label Label1;
        internal System.Windows.Forms.Label Label2;
        internal System.Windows.Forms.TextBox tbMattressIDNumber;
        internal System.Windows.Forms.CheckBox cbMattressPresent;
        internal System.Windows.Forms.Label Label3;
        internal System.Windows.Forms.Label Label4;
        internal System.Windows.Forms.CheckBox cbMattressReplace;
        internal System.Windows.Forms.TextBox tbMattressComments;
        internal System.Windows.Forms.Label Label5;
        internal System.Windows.Forms.Label Label6;
        internal System.Windows.Forms.Label Label7;
        internal System.Windows.Forms.TextBox tbBedFrameComments;
        internal System.Windows.Forms.Label Label8;
        internal System.Windows.Forms.CheckBox cbBedFrameReplace;
        internal System.Windows.Forms.Label Label9;
        internal System.Windows.Forms.CheckBox cbBedFramePresent;
        internal System.Windows.Forms.TextBox tbBedFrameIDNumber;
        internal System.Windows.Forms.Label Label10;
        internal System.Windows.Forms.Label Label11;
        internal System.Windows.Forms.Label Label12;
        internal System.Windows.Forms.TextBox tbDeskComments;
        internal System.Windows.Forms.Label Label13;
        internal System.Windows.Forms.CheckBox cbDeskReplace;
        internal System.Windows.Forms.Label Label14;
        internal System.Windows.Forms.CheckBox cbDeskPresent;
        internal System.Windows.Forms.TextBox tbDeskIDNumber;
        internal System.Windows.Forms.Label Label15;
        internal System.Windows.Forms.Label Label16;
        internal System.Windows.Forms.Label Label17;
        internal System.Windows.Forms.TextBox tbDressersComments;
        internal System.Windows.Forms.Label Label18;
        internal System.Windows.Forms.CheckBox cbDressersReplace;
        internal System.Windows.Forms.Label Label19;
        internal System.Windows.Forms.CheckBox cbDressersPresent;
        internal System.Windows.Forms.TextBox tbDressersIdNumber;
        internal System.Windows.Forms.Label Label20;
        internal System.Windows.Forms.Label Label21;
        internal System.Windows.Forms.ComboBox dlChairsQuantity;
        internal System.Windows.Forms.Label Label22;
        internal System.Windows.Forms.ComboBox dlTrashCanQuantity;
        internal System.Windows.Forms.Label Label23;
        internal System.Windows.Forms.Label Label24;
        internal System.Windows.Forms.TextBox tbRoomComments;
        internal System.Windows.Forms.Button bnSubmit;
    }
}