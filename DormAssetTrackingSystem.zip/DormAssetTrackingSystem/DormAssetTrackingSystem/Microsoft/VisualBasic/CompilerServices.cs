﻿using System;

namespace Microsoft.VisualBasic
{
    internal class CompilerServices
    {
        internal class DesignerGeneratedAttribute : Attribute
        {
        }
    }
}