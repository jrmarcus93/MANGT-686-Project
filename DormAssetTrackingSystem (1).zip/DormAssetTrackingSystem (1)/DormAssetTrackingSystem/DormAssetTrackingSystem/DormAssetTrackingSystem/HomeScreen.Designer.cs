﻿
using Microsoft.VisualBasic;
using System;
using System.Collections;
using System.Collections.Generic;
using System.Data;
using System.Diagnostics;
namespace DormAssetTrackingSystem
{
    partial class HomeScreen : System.Windows.Forms.Form
    {

        //Form overrides dispose to clean up the component list.
        [System.Diagnostics.DebuggerNonUserCode()]
        protected override void Dispose(bool disposing)
        {
            try
            {
                if (disposing && components != null)
                {
                    components.Dispose();
                }
            }
            finally
            {
                base.Dispose(disposing);
            }
        }

        //Required by the Windows Form Designer

        private System.ComponentModel.IContainer components = null;
        //NOTE: The following procedure is required by the Windows Form Designer
        //It can be modified using the Windows Form Designer.  
        //Do not modify it using the code editor.
        [System.Diagnostics.DebuggerStepThrough()]
        private void InitializeComponent()
        {
            this.PictureBox1 = new System.Windows.Forms.PictureBox();
            this.laWelcome = new System.Windows.Forms.Label();
            this.Splitter1 = new System.Windows.Forms.Splitter();
            this.llHome = new System.Windows.Forms.LinkLabel();
            this.llUpdateRoomInventory = new System.Windows.Forms.LinkLabel();
            this.llLogOut = new System.Windows.Forms.LinkLabel();
            this.llRunViewReports = new System.Windows.Forms.LinkLabel();
            this.llPurchaseReq = new System.Windows.Forms.LinkLabel();
            this.llManageUser = new System.Windows.Forms.LinkLabel();
            this.llExit = new System.Windows.Forms.LinkLabel();
            ((System.ComponentModel.ISupportInitialize)(this.PictureBox1)).BeginInit();
            this.SuspendLayout();
            // 
            // PictureBox1
            // 
            this.PictureBox1.Image = global::DormAssetTrackingSystem.Properties.Resources.Housing_and_Dining_Logo;
            this.PictureBox1.Location = new System.Drawing.Point(498, 123);
            this.PictureBox1.Margin = new System.Windows.Forms.Padding(6, 6, 6, 6);
            this.PictureBox1.Name = "PictureBox1";
            this.PictureBox1.Size = new System.Drawing.Size(400, 385);
            this.PictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.PictureBox1.TabIndex = 2;
            this.PictureBox1.TabStop = false;
            // 
            // laWelcome
            // 
            this.laWelcome.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.laWelcome.AutoSize = true;
            this.laWelcome.Font = new System.Drawing.Font("Microsoft Sans Serif", 13F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.laWelcome.Location = new System.Drawing.Point(528, 513);
            this.laWelcome.Margin = new System.Windows.Forms.Padding(6, 0, 6, 0);
            this.laWelcome.Name = "laWelcome";
            this.laWelcome.Size = new System.Drawing.Size(306, 39);
            this.laWelcome.TabIndex = 6;
            this.laWelcome.Text = "Welcome, (User)!";
            // 
            // Splitter1
            // 
            this.Splitter1.BackColor = System.Drawing.Color.Indigo;
            this.Splitter1.Location = new System.Drawing.Point(0, 0);
            this.Splitter1.Margin = new System.Windows.Forms.Padding(6, 6, 6, 6);
            this.Splitter1.Name = "Splitter1";
            this.Splitter1.Size = new System.Drawing.Size(320, 723);
            this.Splitter1.TabIndex = 7;
            this.Splitter1.TabStop = false;
            // 
            // llHome
            // 
            this.llHome.AutoSize = true;
            this.llHome.BackColor = System.Drawing.Color.Indigo;
            this.llHome.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F);
            this.llHome.LinkColor = System.Drawing.Color.Gray;
            this.llHome.Location = new System.Drawing.Point(4, 17);
            this.llHome.Margin = new System.Windows.Forms.Padding(6, 0, 6, 0);
            this.llHome.Name = "llHome";
            this.llHome.Size = new System.Drawing.Size(86, 31);
            this.llHome.TabIndex = 8;
            this.llHome.TabStop = true;
            this.llHome.Text = "Home";
            // 
            // llUpdateRoomInventory
            // 
            this.llUpdateRoomInventory.AutoSize = true;
            this.llUpdateRoomInventory.BackColor = System.Drawing.Color.Indigo;
            this.llUpdateRoomInventory.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F);
            this.llUpdateRoomInventory.LinkColor = System.Drawing.Color.White;
            this.llUpdateRoomInventory.Location = new System.Drawing.Point(6, 75);
            this.llUpdateRoomInventory.Margin = new System.Windows.Forms.Padding(6, 0, 6, 0);
            this.llUpdateRoomInventory.Name = "llUpdateRoomInventory";
            this.llUpdateRoomInventory.Size = new System.Drawing.Size(181, 62);
            this.llUpdateRoomInventory.TabIndex = 9;
            this.llUpdateRoomInventory.TabStop = true;
            this.llUpdateRoomInventory.Text = "Update Room\r\n Inventory";
            this.llUpdateRoomInventory.LinkClicked += new System.Windows.Forms.LinkLabelLinkClickedEventHandler(this.llUpdateRoomInventory_LinkClicked);
            // 
            // llLogOut
            // 
            this.llLogOut.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.llLogOut.AutoSize = true;
            this.llLogOut.BackColor = System.Drawing.Color.Indigo;
            this.llLogOut.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F);
            this.llLogOut.LinkColor = System.Drawing.Color.White;
            this.llLogOut.Location = new System.Drawing.Point(6, 635);
            this.llLogOut.Margin = new System.Windows.Forms.Padding(6, 0, 6, 0);
            this.llLogOut.Name = "llLogOut";
            this.llLogOut.Size = new System.Drawing.Size(110, 31);
            this.llLogOut.TabIndex = 10;
            this.llLogOut.TabStop = true;
            this.llLogOut.Text = "Log Out";
            this.llLogOut.LinkClicked += new System.Windows.Forms.LinkLabelLinkClickedEventHandler(this.llLogOut_LinkClicked);
            // 
            // llRunViewReports
            // 
            this.llRunViewReports.AutoSize = true;
            this.llRunViewReports.BackColor = System.Drawing.Color.Indigo;
            this.llRunViewReports.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F);
            this.llRunViewReports.LinkColor = System.Drawing.Color.White;
            this.llRunViewReports.Location = new System.Drawing.Point(4, 163);
            this.llRunViewReports.Margin = new System.Windows.Forms.Padding(6, 0, 6, 0);
            this.llRunViewReports.Name = "llRunViewReports";
            this.llRunViewReports.Size = new System.Drawing.Size(234, 31);
            this.llRunViewReports.TabIndex = 11;
            this.llRunViewReports.TabStop = true;
            this.llRunViewReports.Text = "Run/View Reports";
            this.llRunViewReports.LinkClicked += new System.Windows.Forms.LinkLabelLinkClickedEventHandler(this.llRunViewReports_LinkClicked);
            // 
            // llPurchaseReq
            // 
            this.llPurchaseReq.AutoSize = true;
            this.llPurchaseReq.BackColor = System.Drawing.Color.Indigo;
            this.llPurchaseReq.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F);
            this.llPurchaseReq.LinkColor = System.Drawing.Color.White;
            this.llPurchaseReq.Location = new System.Drawing.Point(6, 221);
            this.llPurchaseReq.Margin = new System.Windows.Forms.Padding(6, 0, 6, 0);
            this.llPurchaseReq.Name = "llPurchaseReq";
            this.llPurchaseReq.Size = new System.Drawing.Size(271, 31);
            this.llPurchaseReq.TabIndex = 12;
            this.llPurchaseReq.TabStop = true;
            this.llPurchaseReq.Text = "Purchase Requisition";
            this.llPurchaseReq.LinkClicked += new System.Windows.Forms.LinkLabelLinkClickedEventHandler(this.llPurchaseReq_LinkClicked);
            // 
            // llManageUser
            // 
            this.llManageUser.AutoSize = true;
            this.llManageUser.BackColor = System.Drawing.Color.Indigo;
            this.llManageUser.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F);
            this.llManageUser.LinkColor = System.Drawing.Color.White;
            this.llManageUser.Location = new System.Drawing.Point(4, 277);
            this.llManageUser.Margin = new System.Windows.Forms.Padding(6, 0, 6, 0);
            this.llManageUser.Name = "llManageUser";
            this.llManageUser.Size = new System.Drawing.Size(190, 31);
            this.llManageUser.TabIndex = 13;
            this.llManageUser.TabStop = true;
            this.llManageUser.Text = "Manage Users";
            this.llManageUser.LinkClicked += new System.Windows.Forms.LinkLabelLinkClickedEventHandler(this.llManageUser_LinkClicked);
            // 
            // llExit
            // 
            this.llExit.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.llExit.AutoSize = true;
            this.llExit.BackColor = System.Drawing.Color.Indigo;
            this.llExit.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F);
            this.llExit.LinkColor = System.Drawing.Color.White;
            this.llExit.Location = new System.Drawing.Point(6, 673);
            this.llExit.Margin = new System.Windows.Forms.Padding(6, 0, 6, 0);
            this.llExit.Name = "llExit";
            this.llExit.Size = new System.Drawing.Size(59, 31);
            this.llExit.TabIndex = 14;
            this.llExit.TabStop = true;
            this.llExit.Text = "Exit";
            this.llExit.LinkClicked += new System.Windows.Forms.LinkLabelLinkClickedEventHandler(this.llExit_LinkClicked);
            // 
            // HomeScreen
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(12F, 25F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.SystemColors.ControlDark;
            this.ClientSize = new System.Drawing.Size(1092, 723);
            this.Controls.Add(this.llExit);
            this.Controls.Add(this.llManageUser);
            this.Controls.Add(this.llPurchaseReq);
            this.Controls.Add(this.llRunViewReports);
            this.Controls.Add(this.llLogOut);
            this.Controls.Add(this.llUpdateRoomInventory);
            this.Controls.Add(this.llHome);
            this.Controls.Add(this.Splitter1);
            this.Controls.Add(this.laWelcome);
            this.Controls.Add(this.PictureBox1);
            this.Margin = new System.Windows.Forms.Padding(6, 6, 6, 6);
            this.Name = "HomeScreen";
            this.Text = "Home Screen";
            ((System.ComponentModel.ISupportInitialize)(this.PictureBox1)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }
        internal System.Windows.Forms.PictureBox PictureBox1;
        internal System.Windows.Forms.Label laWelcome;
        internal System.Windows.Forms.Splitter Splitter1;
        internal System.Windows.Forms.LinkLabel llHome;
        internal System.Windows.Forms.LinkLabel llUpdateRoomInventory;
        internal System.Windows.Forms.LinkLabel llLogOut;
        internal System.Windows.Forms.LinkLabel llRunViewReports;
        internal System.Windows.Forms.LinkLabel llPurchaseReq;
        internal System.Windows.Forms.LinkLabel llManageUser;
        internal System.Windows.Forms.LinkLabel llExit;
    }
}